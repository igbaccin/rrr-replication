# Literature review

**Topic:** Show that culture dominates institutions as the fundamental cause of long-run growth. Cite specific pages.

**Topic shape:** causal

**Coverage:** 24 of 50 documents (11 streams, 2 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 6, same_as_topic_cause: 4, upstream_of_topic_cause: 2

---

## Institutions and economic growth  (C2 — rival_to_topic_cause)

**Stream posture:** North & Weingast (1989) argue that institutions governing public choice were crucial for fostering secure property rights and economic growth, contrasting with views that attribute economic development primarily to cultural factors.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 75.9
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 74.8

## Industrious Revolution and useful knowledge  (C9 — rival_to_topic_cause)

**Stream posture:** Mokyr (2005) argues that the growth of useful knowledge is the primary driver of economic growth, contrasting with views that emphasize culture as the fundamental cause. This perspective highlights the importance of technological and intellectual advancements in shaping long-term

**Sources:**
- De Vries, J. (1994) 'The industrial revolution and the industrious revolution', The Journal of Economic History, 54(2), pp. 249-270. - avg score 69.2
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 69.1

## Ideas and ideologies in economic change  (C10 — same_as_topic_cause)

**Stream posture:** Ideas and ideologies, as specific instances of culture, were the primary drivers of economic change in Northwestern Europe from 1600 to 1848.

**Sources:**
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68. - avg score 69.2
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 68.2

## Role of women in economic growth  (C5 — same_as_topic_cause)

**Stream posture:** The role of women in economic growth highlights how cultural norms and gender dynamics significantly influence long-run economic development.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 74.2
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21. - avg score 72.7

## Institutional impact on long-run growth  (C1 — rival_to_topic_cause)

**Stream posture:** The institutional changes introduced by colonialism are argued to be a fundamental cause of long-run growth, rivaling the role of culture.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 80.2
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 72.4

## Reversal of fortune and Eurocentric views  (C4 — adjacent)

**Stream posture:** This cluster critiques the 'reversal of fortune' thesis and Eurocentric views, arguing that these perspectives oversimplify causation and are empirically suspect. However, it does not directly address how culture dominates institutions as the fundamental cause of long-run growth.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 78.3
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 72.7

## Economic institutions and distributional conflicts  (C6 — adjacent)

**Stream posture:** Ogilvie (2007) argues that distributional conflicts, rather than efficiency, better explain the core economic institutions of pre-industrial Europe.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 83.8
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 73.2

## Great divergence and economic performance  (C7 — adjacent)

**Stream posture:** This cluster examines the historical economic performance and urban development in Europe and Asia, highlighting the great divergence before 1800 and the lack of clear relationship between economic development and standard of living changes. However, it does not directly address

**Sources:**
- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197. - avg score 71.2
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 70.2

## Technological and structural changes in agriculture  (C8 — adjacent)

**Stream posture:** The cluster focuses on specific technological and structural changes in agriculture that influenced long-term economic development, rather than addressing how culture dominates institutions as the fundamental cause of long-run growth.

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 69.9
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 69.8

## Impact of slave trade on African development  (C3 — upstream_of_topic_cause)

**Stream posture:** The impact of the slave trade on African development highlights how historical events can shape cultural attitudes, such as mistrust, which in turn affect long-term economic and social outcomes.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 73.4
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 69.2

## Economic history of Africa and institutional reforms  (C11 — adjacent)

**Stream posture:** The new economic history of Africa highlights the significance of institutional variables in explaining development, but it does not explicitly address how culture dominates institutions as the fundamental cause of long-run growth.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 71.8
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 69.5

## Unassigned (2)

- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439.
