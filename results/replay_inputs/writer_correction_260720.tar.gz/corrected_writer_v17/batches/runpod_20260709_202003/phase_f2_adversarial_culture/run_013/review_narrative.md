# Literature review

**Topic:** Show that culture dominates institutions as the fundamental cause of long-run growth. Cite specific pages.

**Topic shape:** causal

**Coverage:** 24 of 50 documents (11 streams, 1 unassigned).

**Relation distribution:** adjacent: 19, rival_to_topic_cause: 2, upstream_of_topic_cause: 2

---

## Impact of slave trade on African economic and social development  (C4 — upstream_of_topic_cause)

**Stream posture:** The impact of the slave trade on African economic and social development highlights how historical events can shape cultural attitudes, such as mistrust, which in turn influence long-term outcomes.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 73.4
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 69.2

## Role of institutions in economic growth and property rights  (C2 — adjacent)

**Stream posture:** The evolution of institutions governing public choice in seventeenth-century England was crucial for fostering secure property rights and economic growth, highlighting the role of institutional frameworks in long-term economic development.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 75.9
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 74.8

## Economic divergence and development in Europe and Asia  (C6 — adjacent)

**Stream posture:** This cluster examines the economic divergence between Europe and Asia, highlighting various factors that contributed to this divergence before 1800. The studies focus on urban development, real wages, and institutional changes but do not directly address how culture influences lo

**Sources:**
- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197. - avg score 71.2
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 70.2
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 69.8

## Reevaluating economic performance in Africa and its historical context  (C7 — adjacent)

**Stream posture:** The new economic history of Africa suggests that institutional variables play a crucial role in explaining development, but this perspective does not directly address how culture influences long-run growth.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 71.8
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 69.5

## Economic inequality and institutional advantages for elites  (C8 — adjacent)

**Stream posture:** This cluster examines how institutions in New World societies advantaged elites through various government policies, contributing to the persistence of inequality. However, it does not directly address how culture influences long-run growth.

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 73.2
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 72.7

## Technological and agricultural developments influencing economic growth  (C9 — adjacent)

**Stream posture:** This cluster examines how technological and agricultural advancements, such as the Industrious Revolution and the introduction of barbed wire fencing, influenced economic growth. However, it does not directly address the role of culture in long-run growth.

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 69.9
- De Vries, J. (1994) 'The industrial revolution and the industrious revolution', The Journal of Economic History, 54(2), pp. 249-270. - avg score 69.2

## Role of women in economic growth and development  (C5 — adjacent)

**Stream posture:** The literature on the role of women in economic growth and development highlights significant contributions by African women during pre-colonial and colonial periods, as well as transformations in women's employment and education in the U.S. However, these discussions do not dire

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 74.2
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21. - avg score 72.7

## Ideas, knowledge, and ideologies driving economic change  (C10 — adjacent)

**Stream posture:** The cluster argues that ideas and ideologies were the primary drivers of economic change in Northwestern Europe from 1600 to 1848, contrasting with interest-only theories.

**Sources:**
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68. - avg score 69.2
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 69.1

## Critiques of institutional and geographic explanations for economic development  (C3 — adjacent)

**Stream posture:** This cluster critiques institutional and geographic explanations for economic development, arguing against simplistic views of causation and emphasizing dynamic, endogenous processes.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 83.8
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 78.3

## Complexities in economic growth and environmental impact  (C11 — adjacent)

**Stream posture:** The cluster focuses on the complexities of economic growth and environmental impacts, highlighting factors such as technological advance, social change, and pollution intensities. However, it does not delve into how culture specifically dominates institutions to drive long-run gr

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 69.7
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 68.2

## Institutional changes and colonial impact on economic growth  (C1 — rival_to_topic_cause)

**Stream posture:** The institutional changes introduced by colonialism are argued to be a fundamental driver of economic outcomes in former colonies, challenging the notion that culture is the primary determinant of long-run growth.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 80.2
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 72.4

## Unassigned (1)

- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
