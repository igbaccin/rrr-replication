# Literature review

**Topic:** Show that culture dominates institutions as the fundamental cause of long-run growth. Cite specific pages.

**Topic shape:** causal

**Coverage:** 24 of 50 documents (8 streams, 8 unassigned).

**Relation distribution:** adjacent: 6, rival_to_topic_cause: 8, upstream_of_topic_cause: 2

---

## Institutions and economic growth in England  (C2 — rival_to_topic_cause)

**Stream posture:** North & Weingast argue that the evolution of institutions governing public choice in seventeenth-century England was crucial for fostering secure property rights and economic growth, contrasting views that attribute economic development primarily to culture.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 75.9
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 74.8

## Economic institutions and inequality  (C6 — rival_to_topic_cause)

**Stream posture:** Distributional conflicts are highlighted as a key driver of economic institutions in pre-industrial Europe, challenging the notion that culture is the fundamental cause of long-run growth.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 83.8
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 73.2

## Ideas and ideologies in economic change  (C7 — rival_to_topic_cause)

**Stream posture:** McCloskey argues that ideas and ideologies, rather than institutions or interests, were the primary drivers of economic change in Northwestern Europe from 1600 to 1848. This perspective challenges the notion that culture dominates institutions as the fundamental cause of long-run

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 72.7
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68. - avg score 69.2

## Institutional changes due to colonialism  (C1 — rival_to_topic_cause)

**Stream posture:** The institutional changes introduced by colonialism are argued to be a fundamental driver of long-run economic outcomes, challenging the notion that culture is the primary determinant.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 80.2
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 72.4

## Impact of slave trade on African development  (C4 — upstream_of_topic_cause)

**Stream posture:** The impact of the slave trade on African development highlights how historical events can shape cultural attitudes, such as mistrust, which in turn influence long-term economic outcomes.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 73.4
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 69.2

## Role of women in economic development  (C5 — adjacent)

**Stream posture:** The role of women in economic development is an important aspect that intersects with cultural and institutional factors but does not directly address how culture dominates institutions as the fundamental cause of long-run growth.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 74.2
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21. - avg score 72.7

## Technological and structural changes in economic growth  (C8 — adjacent)

**Stream posture:** The papers in this cluster focus on technological and structural changes that influenced economic growth, rather than directly addressing how culture dominates institutions as the fundamental cause of long-run growth.

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 69.9
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 69.8

## Reversal of fortune and economic development  (C3 — adjacent)

**Stream posture:** The 'reversal of fortune' thesis and the great divergence between Europe and Asia are discussed without directly linking them to cultural factors influencing long-run economic growth. These papers focus on institutional evolution, investment patterns, and policy experiences rathe

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 78.3
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 70.2

## Unassigned (8)

- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177.
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424.
- De Vries, J. (1994) 'The industrial revolution and the industrious revolution', The Journal of Economic History, 54(2), pp. 249-270.
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351.
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406.
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439.
