# Literature review

**Topic:** Prove that institutions are irrelevant to long-run economic growth. Cite specific pages.

**Topic shape:** causal

**Coverage:** 24 of 50 documents (6 streams, 12 unassigned).

**Relation distribution:** adjacent: 8, rival_to_topic_cause: 4

---

## Technological and social factors in economic growth  (C1 — adjacent)

**Stream posture:** The literature on technological and social factors in economic growth emphasizes the role of dynamics of technological advance and social change, rather than focusing on institutional frameworks.

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 83.9
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 80.7

## Institutional adjustments for economic growth  (C2 — adjacent)

**Stream posture:** The cluster discusses how institutional and ideological adjustments are necessary for the efficient use of innovations, which is relevant to economic growth but does not directly address the role of institutions in long-run economic growth.

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 80.7
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 73.8

## Property rights and economic development  (C5 — adjacent)

**Stream posture:** The introduction of barbed wire fencing significantly enhanced agricultural development on the American Plains by enabling farmers to better protect their property rights and reduce externalities from livestock damage.

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 74.3
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 72.2

## Economic growth and well-being during Industrial Revolution  (C6 — adjacent)

**Stream posture:** The decline in biological well-being during the Industrial Revolution highlights that economic growth did not translate into improved health outcomes for the population, particularly due to insufficient income gains and poor childhood nourishment.

**Sources:**
- Clark, G. and Jacks, D. (2007) 'Coal and the industrial revolution, 1700--1869', European Review of Economic History, 11(1), pp. 39-72. - avg score 74.3
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 68.7

## Economic institutions and distributional conflicts  (C4 — rival_to_topic_cause)

**Stream posture:** Distributional conflicts, rather than institutional frameworks, are posited as the primary drivers shaping key economic structures in pre-industrial Europe.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 74.6
- Domar, E. (1970) 'The causes of slavery or serfdom: a hypothesis', The Journal of Economic History, 30(1), pp. 18-32. - avg score 73.5

## Institutions and colonial economic outcomes  (C3 — rival_to_topic_cause)

**Stream posture:** The cluster argues that institutional changes introduced by colonialism are crucial in explaining the reversal in relative incomes among former European colonies, challenging the view that institutions are irrelevant to long-run economic growth.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 74.1
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 71.5

## Unassigned (12)

- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377.
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439.
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177.
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027.
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176.
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73.
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31.
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22.
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332.
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232.
