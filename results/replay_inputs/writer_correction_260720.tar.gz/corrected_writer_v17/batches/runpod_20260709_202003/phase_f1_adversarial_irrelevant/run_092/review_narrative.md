# Literature review

**Topic:** Prove that institutions are irrelevant to long-run economic growth. Cite specific pages.

**Topic shape:** causal

**Coverage:** 24 of 50 documents (8 streams, 1 unassigned).

**Relation distribution:** adjacent: 17, same_as_topic_cause: 6

---

## Institutional changes and economic growth  (C1 — same_as_topic_cause)

**Stream posture:** The evolution of institutions governing public choice in seventeenth-century England was crucial for fostering secure property rights and economic growth.

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 73.7
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 73.0
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 71.5

## Institutional impact on economic outcomes  (C4 — same_as_topic_cause)

**Stream posture:** Institutional structures, which are specific types of institutions, play a crucial role in reducing uncertainties and shaping economic outcomes by specifying efficient property rights and providing effective enforcement.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 73.2
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 72.2
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 70.0

## Economic development and standard of living  (C2 — adjacent)

**Stream posture:** The cluster discusses economic development and changes in the standard of living without explicitly addressing institutions as a causal factor.

**Sources:**
- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197. - avg score 74.2
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 72.3

## Economic growth and policy dynamics  (C7 — adjacent)

**Stream posture:** The cluster discusses economic growth and policy dynamics, focusing on technological advancements and institutional adjustments without explicitly linking these to long-run economic growth through institutions.

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 100.0
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 70.1
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 66.8

## Economic growth and structural changes  (C6 — adjacent)

**Stream posture:** The papers in this cluster focus on various structural changes and their impacts on economic growth, but they do not directly address the role of institutions in long-run economic growth.

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 69.7
- Williamson, J. (1996) 'Globalization, convergence, and history', The Journal of Economic History, 56(2), pp. 277-306. - avg score 68.3
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 67.6

## Environmental and technological factors in economic growth  (C8 — adjacent)

**Stream posture:** The literature on environmental and technological factors in economic growth highlights the importance of external influences like technology improvements and resource management, rather than focusing on institutions as a primary driver of long-run economic growth.

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 74.3
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104. - avg score 66.1
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 65.7

## African economic development and historical factors  (C5 — adjacent)

**Stream posture:** The literature on African economic development highlights diverse historical factors, including slavery, colonial policies, and gender roles, without directly addressing how institutions influence long-run economic growth.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 71.5
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 66.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 65.7

## Historical economic divergence and Industrial Revolution  (C3 — adjacent)

**Stream posture:** This cluster examines various historical factors contributing to economic divergence and industrial development but does not directly address the role of institutions in long-run economic growth.

**Sources:**
- Clark, G. and Jacks, D. (2007) 'Coal and the industrial revolution, 1700--1869', European Review of Economic History, 11(1), pp. 39-72. - avg score 85.3
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 73.6
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 73.2

## Unassigned (1)

- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
