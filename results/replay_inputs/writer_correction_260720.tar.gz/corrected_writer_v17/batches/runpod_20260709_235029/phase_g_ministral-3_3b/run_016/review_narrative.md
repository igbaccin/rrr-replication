# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (9 streams, 2 unassigned).

**Relation distribution:** adjacent: 14, same_as_topic_cause: 4, upstream_of_topic_cause: 4

---

## African institutional legacies, colonialism, and cultural norms  (C6 — same_as_topic_cause)

**Stream posture:** This cluster contends that Africa’s enduring underdevelopment stems from the *specificity* of precolonial/colonial institutions—an institutional legacy that persists as a proximate determinant of governance failures and, by extension, long-run growth. The argument prioritizes his

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 59.3
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 56.0

## Early wage/skill premiums and institutional collapse in Europe  (C5 — upstream_of_topic_cause)

**Stream posture:** This cluster contends that Europe’s early institutional collapse (via guilds and apprenticeship protections) created enduring regional wage gaps, thereby undermining the broader causal mechanism by which institutions sustain long-run growth. The divergence in skill premiums—roote

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5

## Path dependence and differentiated historical interactions  (C3 — upstream_of_topic_cause)

**Stream posture:** Austin critiques the ‘reversal of fortune’ thesis for oversimplifying long-term economic causation by ignoring path-dependent regional institutional dynamics. His work highlights how historical reversals—like Ghana’s land scarcity from cocoa booms—shaped institutions *before* the

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4

## Colonialism and institutional divergence in Europe/New World/Africa  (C2 — adjacent)

**Stream posture:** Colonialism and institutional divergence in Europe/New World/Africa

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5

## Endogenous growth and institutional-technological interplay  (C4 — adjacent)

**Stream posture:** Endogenous growth and institutional-technological interplay

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 62.0
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 59.9

## Institutional design and property rights in public choice systems  (C1 — adjacent)

**Stream posture:** Institutional design and property rights in public choice systems

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Misguided narratives on human progress and gendered contributions  (C7 — adjacent)

**Stream posture:** This cluster critiques how Enlightenment-era and colonial narratives systematically erased women’s pre-colonial contributions to trade and agriculture, undermining their long-term economic agency. While institutions shape growth, the critique here lies in *how progress is histori

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7

## Structural inequalities and labor misallocation in modernization  (C8 — adjacent)

**Stream posture:** Structural inequalities and labor misallocation in modernization

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6

## Misleading metrics of growth and institutional decay  (C9 — adjacent)

**Stream posture:** Misleading metrics of growth and institutional decay

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 56.4

## Unassigned (2)

- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15.
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926.
