# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (10 streams, 1 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 6, same_as_topic_cause: 5

---

## Institutional stability and property rights as core drivers of long-term growth  (C1 — adjacent)

**Stream posture:** Institutional stability and property rights as core drivers of long-term growth

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Early wage/skill premium collapse and regional divergence in Europe  (C5 — same_as_topic_cause)

**Stream posture:** This cluster reframes institutions as a **structural driver** of Europe’s early wage stagnation (15th century), where demand-side pressures and formal arrangements (e.g., guilds) shaped persistent skill premium collapse—an upstream precondition for the broader ‘Great Divergence’

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5

## Historical institutional legacies and systemic exclusion in Africa/Eurasia  (C4 — same_as_topic_cause)

**Stream posture:** This cluster reframes institutions as a product of elite dominance, arguing that Africa/Eurasia’s systemic exclusion stems from historically entrenched extractive structures—where power concentrates in elites to perpetuate inequality. The focus on ‘institutional paths’ underscore

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 59.3

## Colonialism’s extractive institutions and long-term divergence  (C2 — adjacent)

**Stream posture:** Colonialism’s extractive institutions and long-term divergence

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2

## Path dependence, regional divergence, and entrepreneurial agency in growth  (C6 — adjacent)

**Stream posture:** Path dependence, regional divergence, and entrepreneurial agency in growth

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4

## Innovation, labor misallocation, and ideological frameworks in growth  (C7 — adjacent)

**Stream posture:** Innovation, labor misallocation, and ideological frameworks in growth

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6

## Undervalued contributions and systemic exclusion in African economic history  (C9 — adjacent)

**Stream posture:** Undervalued contributions and systemic exclusion in African economic history

**Sources:**
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15. - avg score 57.9
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7

## Path-dependent distributional conflicts shaping pre-industrial institutions  (C3 — rival_to_topic_cause)

**Stream posture:** This cluster contends that **distributional power struggles**—not efficiency-driven institutional design—driven early European institutions, directly challenging the conventional view that institutions emerge from rational optimization. Their argument reframes long-run divergence

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5

## Endogenous factors in catch-up and structural inequality  (C8 — rival_to_topic_cause)

**Stream posture:** While Abramovitz highlights endogenous forces—such as trade rivalry and shifting social priorities—as shaping long-run growth, his work contests the primacy of *institutions* alone by exposing how these multifaceted drivers interact with technological opportunity in ways that ins

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 59.9

## Enduring cultural and institutional legacies from the slave trade  (C10 — rival_to_topic_cause)

**Stream posture:** This cluster contends that the African slave trade created enduring cultural distrust as a *fundamental* driver of long-run underdevelopment, bypassing direct institutional decay. While institutions remain relevant, the focus shifts to how slavery’s social scars—like mistrust—per

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 56.0

## Unassigned (1)

- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258.
