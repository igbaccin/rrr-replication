# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (11 streams, 0 unassigned).

**Relation distribution:** adjacent: 12, rival_to_topic_cause: 7, same_as_topic_cause: 4

---

## Historical institutional legacies and colonialism’s enduring effects on governance  (C4 — same_as_topic_cause)

**Stream posture:** This cluster refines the topic by emphasizing how **extractive institutions**—shaped by precolonial and colonial eras—persist as a proximate driver of governance failures in Africa, thereby undermining long-term growth through entrenched elite dominance and cultural fragmentation

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 56.0

## Extractive colonial institutions shaping modern income disparities  (C2 — adjacent)

**Stream posture:** Extractive colonial institutions shaping modern income disparities

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2

## Stable constitutional institutions and property rights as core drivers of long-term growth  (C1 — adjacent)

**Stream posture:** Stable constitutional institutions and property rights as core drivers of long-term growth

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Economic divergence and skill premiums in early modern Europe  (C5 — adjacent)

**Stream posture:** Economic divergence and skill premiums in early modern Europe

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5

## Structural inequalities and ideological frameworks in long-term growth  (C7 — adjacent)

**Stream posture:** Structural inequalities and ideological frameworks in long-term growth

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 62.0
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9

## Undervalued contributions of marginalized groups and systemic exclusion in Africa  (C9 — adjacent)

**Stream posture:** Undervalued contributions of marginalized groups and systemic exclusion in Africa

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 59.3
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7

## Distributional conflicts shaping pre-industrial European institutions  (C3 — adjacent)

**Stream posture:** Distributional conflicts shaping pre-industrial European institutions

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5

## Path dependence, institutional adaptation, and regional economic divergence  (C6 — rival_to_topic_cause)

**Stream posture:** This cluster challenges the AJR thesis by emphasizing *path-dependent institutional adaptation* as a distinct mechanism for explaining long-run divergence, rejecting the idea that institutions alone suffice. Their focus on regional divergence highlights how historical lock-in in

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4

## Misguided assumptions vs. effective drivers of growth (Enlightenment vs. Baconian empiricism)  (C8 — rival_to_topic_cause)

**Stream posture:** Mokyr critiques Enlightenment-era optimism for its exaggerated faith in reason-driven progress, contrasting it with Baconian empiricism’s role in *practical* institutional and technological innovation as the true engines of sustained growth.

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 59.9

## Labor misallocation, wage stagnation, and structural shifts post-industrialization  (C10 — rival_to_topic_cause)

**Stream posture:** Temin (2002) contends that post-WWII Europe’s growth stemmed from *structural labor misallocation*—a disequilibrium in surplus agricultural workers—that resolved by the 1970s, bypassing policy-driven institutional reforms. This challenges the dominant narrative of institutions as

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 56.4

## Rigorous interdisciplinary progress in African precolonial economic history  (C11 — rival_to_topic_cause)

**Stream posture:** Hopkins (2019) contests the conventional narrative that African precolonial gaps were insurmountable by reframing them as a *testbed for interdisciplinary rigor*—a rival cause to institutions’ direct role in growth. The cluster’s claim is one of methodological critique, not causa

**Sources:**
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15. - avg score 57.9
