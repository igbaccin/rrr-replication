# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (9 streams, 0 unassigned).

**Relation distribution:** adjacent: 14, rival_to_topic_cause: 2, same_as_topic_cause: 3, upstream_of_topic_cause: 2

---

## Extractive colonial institutions and their long-term growth effects  (C2 — upstream_of_topic_cause)

**Stream posture:** This cluster contends that colonialism’s institutional design—by systematically undermining pre-colonial elites’ wealth in prosperous regions and reinforcing extractive structures elsewhere—constitutes a foundational, irreversible disruption of endogenous growth drivers. The argu

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2

## African institutional legacies and colonial-era governance failures  (C6 — adjacent)

**Stream posture:** This cluster highlights how Africa’s precolonial and colonial legacies—including institutional collapse and cultural fragmentation—perpetuate contemporary governance failures by embedding systemic underdevelopment in economic and social structures, requiring policy reforms anchor

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 56.0

## Institutional stability and property rights as core drivers of long-term growth  (C1 — adjacent)

**Stream posture:** Institutional stability and property rights as core drivers of long-term growth

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Distributional conflicts and elite-driven institutional inequality  (C4 — adjacent)

**Stream posture:** Distributional conflicts and elite-driven institutional inequality

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9

## Early wage and skill premium dynamics shaping long-term divergence  (C5 — adjacent)

**Stream posture:** Early wage and skill premium dynamics shaping long-term divergence

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5

## Endogenous factors in catch-up growth and interdisciplinary progress  (C7 — adjacent)

**Stream posture:** Endogenous factors in catch-up growth and interdisciplinary progress

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 59.9
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15. - avg score 57.9

## Path dependence and regional divergence in long-term economic history  (C3 — same_as_topic_cause)

**Stream posture:** This cluster refines the ‘institutions-as-fundamental-cause’ thesis by emphasizing that long-run divergence stems from **path-dependent institutional divergence**—how regional histories shape which institutions persist or collapse. It rejects simplistic ‘reversal-of-fortune’ narr

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4

## Ideological frameworks and structural labor misallocation in growth  (C8 — adjacent)

**Stream posture:** This cluster broadens the causal lens beyond Kuznets’ ‘institutions’ to include *ideological alignment* and structural equilibria, framing growth as a function of systemic support rather than mere institutional form. While it shares the topic’s outcome, its cause is not a downstr

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 62.0
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6

## Misguided narratives vs. empirical innovation in growth drivers  (C9 — rival_to_topic_cause)

**Stream posture:** While Mokyr’s paper critiques Enlightenment-era narratives by emphasizing Baconian empiricism and industrial innovation as the true engines of long-run growth, it rejects institutional progress as a necessary or sufficient condition for such growth. The cluster thus offers an alt

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7
