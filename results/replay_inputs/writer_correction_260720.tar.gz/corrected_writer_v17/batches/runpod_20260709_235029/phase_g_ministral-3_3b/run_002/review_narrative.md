# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (10 streams, 2 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 7, upstream_of_topic_cause: 5

---

## Stable constitutional institutions as core drivers of long-term growth  (C2 — adjacent)

**Stream posture:** Stable constitutional institutions as core drivers of long-term growth

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Institutional transformations driven by regional economic shocks  (C7 — adjacent)

**Stream posture:** Institutional transformations driven by regional economic shocks

**Sources:**
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9

## Institutions, ideology, and technological deployment for sustained growth  (C6 — upstream_of_topic_cause)

**Stream posture:** This cluster contends that sustained economic growth depends not merely on institutions but on the *preceding ideological climate*—specifically, Enlightenment-era optimism and Baconian empiricism—that enables institutions to efficiently diffuse innovations. The review should note

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 62.0

## African institutional legacies and systemic exclusion under globalization  (C5 — upstream_of_topic_cause)

**Stream posture:** This cluster argues that Africa’s long-term economic stagnation stems from *institutional legacies* shaped by precolonial and colonial governance failures—specifically how these eras systematically undervalued African women’s contributions, creating a feedback loop of exclusion u

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 59.3
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7

## Elite dominance and unequal institutional paths in New World societies  (C4 — adjacent)

**Stream posture:** This cluster critiques elite dominance by framing persistent inequality not as a direct consequence of institutions but as an *institutional path dependency* enabled by exclusionary policies, which preempted inclusive governance—distinct from the topic’s focus on institutions’ ca

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9

## Enduring cultural norms from the slave trade in Africa  (C9 — adjacent)

**Stream posture:** This cluster argues that Africa’s slave trade fostered enduring economic stagnation not through direct institutional decay but by embedding persistent internal mistrust in socialization, shaping long-term cultural and economic dynamics distinct from formal institutions.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 56.0

## Colonialism’s extractive institutions and modern income divergence  (C3 — adjacent)

**Stream posture:** Colonialism’s extractive institutions and modern income divergence

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2

## Reassessing African colonial-era economic performance and wage trends  (C10 — rival_to_topic_cause)

**Stream posture:** Frankema and van Waijenburg reject the structuralist narrative that African colonial-era poverty is intrinsic by highlighting empirical wage improvements (1880–1965), thereby undermining the assumption that institutions alone determine long-run growth outcomes. Their work does no

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 55.5

## Post-industrial structural misallocations and wage stagnation revisited  (C8 — rival_to_topic_cause)

**Stream posture:** This cluster contends that Europe’s post-war growth stemmed from *structural labor misallocation*—a proximate disequilibrium rather than policy-driven institutional forces. While institutions enabled demand, the core driver was surplus agricultural workers’ reallocation until exh

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 56.4

## Institutional origins of pre-industrial European inequality and path dependence  (C1 — rival_to_topic_cause)

**Stream posture:** This cluster challenges the ‘institutions-as-causal-mechanism’ thesis by arguing that distributional conflicts *preceded* and *shaped* institutions (e.g., serfdom) rather than institutions directly fueling growth. Their work reframes the ‘why’ of institutional divergence as a zer

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5

## Unassigned (2)

- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406.
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15.
