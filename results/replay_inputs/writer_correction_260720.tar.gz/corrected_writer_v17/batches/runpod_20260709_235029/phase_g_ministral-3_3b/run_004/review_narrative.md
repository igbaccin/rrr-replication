# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (11 streams, 0 unassigned).

**Relation distribution:** adjacent: 15, rival_to_topic_cause: 4, same_as_topic_cause: 2, upstream_of_topic_cause: 1

---

## Distributional conflicts and early institutional formation  (C1 — adjacent)

**Stream posture:** Distributional conflicts and early institutional formation

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5

## Stable constitutional and property rights as growth foundations  (C2 — adjacent)

**Stream posture:** Stable constitutional and property rights as growth foundations

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Colonialism’s extractive institutional legacy  (C3 — adjacent)

**Stream posture:** Colonialism’s extractive institutional legacy

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2

## Elite dominance and unequal institutional paths in New World societies  (C4 — adjacent)

**Stream posture:** This cluster’s focus on elite dominance as a *structural* force shaping institutions diverges from the broader topic’s framing of institutions as the direct cause of long-run growth. While Sokoloff & Engerman highlight how elites preserved inequality through institutional design,

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9

## Path dependence and regional institutional divergence  (C5 — adjacent)

**Stream posture:** Path dependence and regional institutional divergence

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4

## Early wage and skill premium divergence in Europe  (C6 — adjacent)

**Stream posture:** Early wage and skill premium divergence in Europe

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5

## Ideological and institutional support for technological deployment  (C7 — same_as_topic_cause)

**Stream posture:** This cluster reframes institutions as ‘ideological frameworks’—a more granular but conceptually aligned variable—that must sustain technological deployment to drive long-run growth. The paper argues that without such ideological backing, innovations (e.g., steam power) remain und

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 62.0

## African institutional legacies and colonial-era governance failures  (C8 — adjacent)

**Stream posture:** African institutional legacies and colonial-era governance failures

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 56.0

## Post-industrial labor misallocation and wage stagnation narratives  (C9 — rival_to_topic_cause)

**Stream posture:** This cluster contends that post-WWII Europe’s growth stemmed from *short-lived* labor misallocations (e.g., surplus agricultural workers) rather than enduring institutional reforms, thereby framing a rival proximate cause to the topic’s focus on institutions as foundational drive

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 56.4

## Undervalued contributions of marginalized groups in institutional contexts  (C10 — rival_to_topic_cause)

**Stream posture:** While the broader literature frames institutions as the bedrock of long-run growth, this cluster contends that exclusionary policies—such as those imposed by colonialism or elite capture—actively stifle development potential *independently* of formal institutional design. Their a

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 59.3
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7

## Interdisciplinary progress on African economic history  (C11 — upstream_of_topic_cause)

**Stream posture:** This cluster reframes African economic history as a site where *interdisciplinary innovation*—not just institutions alone—must first materialize before institutions can sustain growth. Hopkins (2019) argues that precolonial gaps were not insurmountable but required *contextualize

**Sources:**
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15. - avg score 57.9
