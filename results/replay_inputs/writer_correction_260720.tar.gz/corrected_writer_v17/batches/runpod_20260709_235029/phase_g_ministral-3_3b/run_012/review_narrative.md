# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (8 streams, 5 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 3, upstream_of_topic_cause: 6

---

## Path-dependent institutional divergence and regional specialization  (C3 — upstream_of_topic_cause)

**Stream posture:** This cluster reframes institutions as a *mediating mechanism* in a broader causal chain, where historical path dependence (e.g., colonial legacies or technological lock-in) is the ultimate driver of divergent institutional trajectories. The review should note that while instituti

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9

## Historical institutional legacies and contemporary governance failures  (C5 — upstream_of_topic_cause)

**Stream posture:** This cluster contends that Africa’s long-term underdevelopment stems from how precolonial and colonial-era institutions persistently structure modern governance—an argument rooted in historical institutional legacies rather than contemporary failures alone.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 59.3
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1

## Elite dominance and exclusionary institutional paths  (C4 — rival_to_topic_cause)

**Stream posture:** This cluster rejects the conventional framing that institutions alone drive long-run growth by instead emphasizing how elite exclusionary policies *constitute* persistent inequality—an upstream mechanism that bypasses institutional intermediation. Their work critiques North’s (19

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9

## Colonial extractive institutions as drivers of long-term divergence  (C2 — adjacent)

**Stream posture:** Colonial extractive institutions as drivers of long-term divergence

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2

## Institutional stability and property rights as core drivers of long-term growth  (C1 — adjacent)

**Stream posture:** Institutional stability and property rights as core drivers of long-term growth

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Institutional transformations driven by labor markets and wage dynamics  (C6 — adjacent)

**Stream posture:** Institutional transformations driven by labor markets and wage dynamics

**Sources:**
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5

## Structural labor misallocations and undervalued contributions in growth narratives  (C8 — adjacent)

**Stream posture:** While Temin (2002) and Akyeampong & Fofack (2014) both highlight how structural misallocations and gendered undervaluation undermine long-term growth, the latter’s critique of colonial policies instead frames institutional neglect as a *preceding* systemic distortion—one that pre

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6

## Misattributed drivers of economic progress and empirical innovation  (C7 — adjacent)

**Stream posture:** This paper rejects the claim that institutions are the sole engine of long-run economic growth, arguing instead that Enlightenment-era optimism—rooted in reason and knowledge—was exaggerated. It does not engage directly with institutional mechanisms but critiques how historical n

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 56.4

## Unassigned (5)

- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15.
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176.
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926.
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406.
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258.
