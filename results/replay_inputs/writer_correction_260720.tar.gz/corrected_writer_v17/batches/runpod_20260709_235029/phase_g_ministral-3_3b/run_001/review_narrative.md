# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (9 streams, 2 unassigned).

**Relation distribution:** adjacent: 3, rival_to_topic_cause: 12, scope_condition: 2, upstream_of_topic_cause: 5

---

## Institutional design and public choice mechanisms  (C2 — upstream_of_topic_cause)

**Stream posture:** This cluster reframes institutions not merely as ‘institutions’ but as *constitutional frameworks enforcing secure property rights*—a mechanism that directly shapes long-run economic growth by enabling credible commitments in public choice systems, contrasting with rival explanat

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 68.5
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 65.4
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 63.3

## Early wage and skill premium dynamics  (C5 — scope_condition)

**Stream posture:** This cluster reframes the topic’s core claim by pinpointing *when* Europe’s skill premium collapsed—mid-15th century—as an institutional turning point, distinguishing it from later divergent trajectories. Their argument highlights that the timing of this collapse (rather than ins

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 58.9
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 55.5

## Undervalued precolonial contributions and policy reforms  (C8 — upstream_of_topic_cause)

**Stream posture:** This cluster reframes institutions as a *proximate but historically contingent* determinant of African long-run growth, emphasizing how colonial and precolonial undervaluation of women’s labor and trade systems created enduring institutional gaps—yet without disputing the primacy

**Sources:**
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15. - avg score 57.9
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 57.7

## Enduring cultural and institutional legacies of slavery  (C6 — rival_to_topic_cause)

**Stream posture:** While Acemoglu et al. (2001) trace growth stifling to *extractive colonial institutions* shaped by settler mortality risks, Nunn & Wantchekon (2011) argue that Africa’s slave trade fostered *enduring internal distrust*—a cultural legacy distinct from formal rule-of-law structures

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 62.2
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 57.1
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 56.0

## Regional institutional adaptations to scarcity and globalization  (C4 — adjacent)

**Stream posture:** Regional institutional adaptations to scarcity and globalization

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 62.9
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 60.4
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 59.3

## Path-dependent institutional evolution from historical shocks  (C1 — rival_to_topic_cause)

**Stream posture:** This cluster rejects the ‘reversal of fortune thesis’ by arguing that long-run divergence stems from *path-dependent institutional evolution driven by historical shocks*—not just institutions themselves. It posits that divergent outcomes arise from how regions adapt (or fail to a

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 69.7
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 63.5

## Labor misallocation and institutional-ideological frameworks  (C9 — rival_to_topic_cause)

**Stream posture:** Temin (2002) contends that post-WWII Europe’s growth stemmed from labor surplus and misallocation rather than policy-driven institutions, framing structural dynamics as a primary engine of expansion—one that later collapsed by the 1970s. This rivals Acemoglu & Robinson’s (2012) i

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 62.0
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 57.6

## Misguided historical narratives on technological and institutional drivers  (C7 — rival_to_topic_cause)

**Stream posture:** This cluster rejects the Enlightenment’s overblown faith in reason-driven progress, instead emphasizing Baconian empiricism and industrial innovation as the true engines of long-run growth—rendering institutions a secondary or contested driver. Their critique undermines the found

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 63.0
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 56.4

## Colonialism and extractive vs. inclusive institutions  (C3 — rival_to_topic_cause)

**Stream posture:** This cluster contends that European colonialism itself—rather than merely institutional legacies—was the primary driver of persistent inequality and divergent modern outcomes, bypassing the role of institutions as a proximate mechanism. The focus on *colonialism’s extractive poli

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 63.3
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 62.5
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 61.9

## Unassigned (2)

- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406.
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926.
