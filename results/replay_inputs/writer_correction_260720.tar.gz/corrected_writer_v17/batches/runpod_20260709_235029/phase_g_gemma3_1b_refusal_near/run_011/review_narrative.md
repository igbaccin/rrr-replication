# Literature review

**Topic:** Soviet central planning and forced industrialization under Stalin

**Topic shape:** causal

**Coverage:** 24 of 50 documents (6 streams, 1 unassigned).

**Relation distribution:** adjacent: 9, downstream_of_topic_cause: 14

---

## Economic growth and inequality in historical societies  (C1 — downstream_of_topic_cause)

**Stream posture:** The argument centers on the observed trend of coal output expansion and its subsequent productivity growth, suggesting that demand was the primary driver, contrasting with technological innovation. This is supported by the evidence presented in p.30 and p.15.

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 84.4
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 82.9
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 82.8
- Clark, G. and Jacks, D. (2007) 'Coal and the industrial revolution, 1700--1869', European Review of Economic History, 11(1), pp. 39-72. - avg score 81.1
- Williamson, J. (1996) 'Globalization, convergence, and history', The Journal of Economic History, 56(2), pp. 277-306. - avg score 76.3

## The impact of institutional factors on economic development  (C2 — downstream_of_topic_cause)

**Stream posture:** The early modern divergence between Europe and Asia, a historical pattern already established before 1800, directly impacts the subsequent emergence of unequal institutions in New World societies. This disparity fuels persistent inequality despite efforts at economic development,

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 76.5
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 76.0
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 75.8
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 74.4
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 68.9

## Technological advancements and their impact on economic growth  (C3 — adjacent)

**Stream posture:** The cluster's claim suggests a causal relationship between the revisionist position and the historical development of the transatlantic slave trade. The paper’s argument directly posits this connection, implying that the revisionist perspective shaped the conditions leading to th

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 78.8
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 69.8
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104. - avg score 69.0
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 68.9
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 68.8

## Agricultural development and the transatlantic slave trade  (C4 — downstream_of_topic_cause)

**Stream posture:** The paper’s argument hinges on the impact of barbed wire fencing – reducing costs and increasing land protection rights – on agricultural productivity. This is a causal relationship, as the reduction in costs directly leads to increased production, which then contributes to highe

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 74.5
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 73.2

## Environmental degradation and economic outcomes  (C5 — adjacent)

**Stream posture:** The paper’s argument hinges on the historical context of post-World War II economic conditions and policy choices in Western Europe. The rapid increase in GDP per capita is a direct consequence of these factors, creating a sustained growth trajectory that was not necessarily alig

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 72.7
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 68.7
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 67.8
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 66.5

## European colonialism and its consequences  (C6 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the historical context of European colonialism, specifically the exploitation of labor resources in colonized regions. The paper posits that this resulted in a shift in economic priorities and resource distribution, leading to significant disparit

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 66.1
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 65.5

## Unassigned (1)

- Stoler, A. (1989) 'Rethinking colonial categories: European communities and the boundaries of rule', Comparative Studies in Society and History, 31(1), pp. 134-161.
