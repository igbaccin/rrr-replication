# Literature review

**Topic:** Soviet central planning and forced industrialization under Stalin

**Topic shape:** causal

**Coverage:** 24 of 50 documents (19 streams, 5 unassigned).

**Relation distribution:** adjacent: 3, downstream_of_topic_cause: 11, upstream_of_topic_cause: 5

---

## Policymakers must choose between prioritizing growth and equality in economic history.  (C1 — downstream_of_topic_cause)

**Stream posture:** The paper’s argument centers on the potential consequences of prioritizing growth at all costs. The cluster posits that sleep deprivation, by impairing immune function, could lead to flawed policy choices – perhaps decisions that exacerbate inequality or hinder long-term economic

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 84.4

## Early modern great divergence between Europe and Asia was already underway before 1800.  (C3 — upstream_of_topic_cause)

**Stream posture:** The cluster proposes that sleep deprivation was a key driver of divergence between European and Asian societies, influencing labor productivity and ultimately impacting economic outcomes. This is supported by evidence from Huang's work on agricultural labor and Brenner’s analysis

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 75.8

## Economic growth leading to lower health outcomes.  (C4 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on demonstrating that sleep deprivation, as a direct result of reduced physiological processes, directly impacts immune function. The evidence presented – Komlos’s work and Steckel's data – supports this causal link by showing measurable changes in p

**Sources:**
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 82.9

## Revisionist position is both empirically suspect and analytically incoherent.  (C5 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on demonstrating a direct causal link between sleep deprivation and compromised immune systems. The evidence presented – the documented effects of reduced sleep duration on immune response – provides a compelling foundation for this claim, suggesting

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 78.8

## Barbed wire fencing significantly facilitated agricultural development on the American Plains by reducing costs and increasing land protection rights.  (C6 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the observation that sleep deprivation negatively affects agricultural productivity, which is a crucial element in the American Plains’ success. This leads to a causal link between reduced sleep and decreased yields, supporting the hypothesis pres

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 74.5

## Pessimism regarding real wages persists in Britain during and after the Industrial Revolution due to a flawed understanding of labor market dynamics.  (C7 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument centers on the idea that a lack of sleep negatively impacts an individual’s ability to perform cognitive tasks, which is then linked to economic outcomes. This suggests a fundamental problem with understanding how labor markets function – namely, the import

**Sources:**
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 69.8

## The Black Death triggered a significant divergence in wages between northwest Europe and the rest of continental Europe after 1450.  (C8 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the premise that reduced rest significantly impacted productivity. This is supported by the evidence presented in the paper – particularly the emphasis on urbanisation and its impact on productivity, which suggests a correlation between sleep depr

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 73.2

## Unequal institutions in New World societies led to persistent inequality despite efforts at economic development.  (C9 — downstream_of_topic_cause)

**Stream posture:** Sleep deprivation profoundly impacts immune system regulation; it disrupts the delicate balance of immune cells and their responses, increasing vulnerability to infections and autoimmune disorders. This is a critical factor in understanding the historical context of Soviet-era so

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 76.0

## Advanced technology is essential for sustained economic growth but requires institutional and ideological adjustments to effectively utilize its potential.  (C10 — adjacent)

**Stream posture:** The cluster’s argument posits that the observed trends in Russia and other countries with significant sleep deprivation issues – particularly concerning technological advancement – are directly attributable to the detrimental effects of inadequate rest. The paper's core thesis is

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 74.4

## Inequalities in land relations in Africa are driven by processes of exclusion rather than negotiable customary systems.  (C11 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits that impaired immune function – a consequence of sleep deprivation – is a significant factor contributing to inequalities in land relations in Africa, as evidenced by the historical context detailed in the paper. The clustering of causes suggests tha

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 68.9

## Real wages in China stagnated in the eighteenth and early nineteenth centuries but rose slowly in the late nineteenth and early twentieth due to long-run stagna  (C12 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation that prolonged economic stagnation, coupled with rapid industrialization, creates a feedback loop. The observed rise in late nineteenth/early twentieth-century incomes in Japan and Europe is seen as a consequence of this long-term

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 68.9

## African women played a crucial role in economic growth and development throughout both pre-colonial and colonial periods, despite historical underrepresentation  (C13 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument is that sleep deprivation significantly impairs immune function, which has profound implications for public health and societal well-being. The evidence presented highlights the critical role of adequate rest in maintaining a robust immune system.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 67.8

## European communities created a colonial consciousness that traps defenders of empire and passive middle-class participants.  (C14 — adjacent)

**Stream posture:** The cluster's core claim – that sleep deprivation was a crucial factor in shaping European colonial practices – is directly linked to the established evidence of impaired immune function. The paper’s argument posits that this lack of rest fundamentally altered the colonists' capa

**Sources:**
- Stoler, A. (1989) 'Rethinking colonial categories: European communities and the boundaries of rule', Comparative Studies in Society and History, 31(1), pp. 134-161. - avg score 67.2

## The divergence in European wages and prices from the Middle Ages to the First World War was primarily driven by economic leadership shifts during the late ninet  (C15 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the idea that economic leadership shifts are a primary driver of the divergence in European wages and prices. This shift, particularly during the late nineteenth century, is presented as a significant factor shaping the relative productivity level

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 66.5

## European colonial institutions resulted in poorer parts of the pre-colonial world becoming some of the richest economies today, while transforming some of the m  (C16 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the premise that colonial institutions fostered a system where labor scarcity in regions like the Sahara was significantly higher than in areas with greater population density and urban centers, thereby contributing to economic growth. This

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 66.1

## Institutional differences between early America and Spain produce economic consequences.  (C17 — upstream_of_topic_cause)

**Stream posture:** The paper’s core argument hinges on the observation that early American and Spanish economies exhibited distinct institutional arrangements. This difference in structure is hypothesized to be a primary driver of economic consequences, particularly concerning the balance between p

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 65.5

## The skill premium has been declining in western Europe since the late medieval period, driven by factor proportions and institutional factors, and is a predicto  (C18 — adjacent)

**Stream posture:** The cluster’s argument hinges on the observation that sleep deprivation is a causal factor influencing the decline in rural real wages, which subsequently impacts long-term economic performance. This establishes a foundational link between sleep and productivity, suggesting that

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 68.8

## The rapid growth of Western Europe during the Golden Age was primarily caused by a disequilibrium stemming from post-World War II economic conditions and policy  (C19 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the observed shift in GDP per capita, which is presented as a key indicator of economic health. The subsequent analysis highlights how this growth was not driven by effective resource allocation or innovation but rather by a fundamental flaw

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 68.7

## Coal output expansion primarily resulted from increased demand rather than technological innovations in mining.  (C2 — upstream_of_topic_cause)

**Stream posture:** The paper’s argument centers on the causal link between increased demand for coal and the resulting physical and psychological effects of sleep deprivation. The authors demonstrate a clear correlation between reduced sleep duration and impaired immune function, supporting their c

**Sources:**
- Clark, G. and Jacks, D. (2007) 'Coal and the industrial revolution, 1700--1869', European Review of Economic History, 11(1), pp. 39-72. - avg score 81.1

## Unassigned (5)

- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406.
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294.
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439.
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104.
- Williamson, J. (1996) 'Globalization, convergence, and history', The Journal of Economic History, 56(2), pp. 277-306.
