# Literature review

**Topic:** Soviet central planning and forced industrialization under Stalin

**Topic shape:** causal

**Coverage:** 24 of 50 documents (18 streams, 6 unassigned).

**Relation distribution:** adjacent: 2, downstream_of_topic_cause: 10, upstream_of_topic_cause: 6

---

## Policymakers must balance growth and equality in economic history.  (C1 — upstream_of_topic_cause)

**Stream posture:** Historical evidence suggests a complex relationship between these two goals, highlighting that policymakers must balance growth and equality in economic history. The sleep deprivation scenario is presented as a potential causal factor, suggesting that reduced rest can negatively

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 84.4

## Simple statement of the catch-up hypothesis might suggest that dramatic changes in productivity rankings mark the performance of a group’s individual members.  (C3 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the observation that sleep deprivation can negatively impact cognitive functions and physical health, which are crucial for productivity. This suggests a causal link between these factors, requiring further investigation into how specific levels o

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 82.8

## Coal output expansion primarily resulted from increased demand rather than technological innovations in mining.  (C4 — upstream_of_topic_cause)

**Stream posture:** The paper’s analysis highlights that increased demand for coal output is a primary driver of coal production expansion. This observation underscores the importance of understanding the economic forces behind resource extraction, particularly within the context of industrializatio

**Sources:**
- Clark, G. and Jacks, D. (2007) 'Coal and the industrial revolution, 1700--1869', European Review of Economic History, 11(1), pp. 39-72. - avg score 81.1

## The revisionist position is both empirically suspect and analytically incoherent.  (C5 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation that increased productivity was prioritized over worker well-being, implicitly suggesting that sleep deprivation would enhance efficiency. This is presented as a crucial element in Stalin's calculated manipulation of the population

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 78.8

## European colonialism reversed fortune by creating an institutional reversal among former colonies, leading to a reversal in relative incomes.  (C6 — downstream_of_topic_cause)

**Stream posture:** The paper’s central claim – that colonial exploitation fostered lasting economic disparities – is predicated on the understanding that disrupted sleep patterns negatively impact immune system health. This premise directly links a historical condition (colonialism) to a measurable

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 76.5

## Unequal institutions in New World societies led to persistent inequality despite efforts at economic development.  (C7 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument is that sleep deprivation played a crucial role in perpetuating inequality. The persistent differences in access to opportunities – including adequate rest and recovery – between wealthy and impoverished populations, fueled by the colonial system, cre

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 76.0

## Barbed wire fencing significantly facilitated agricultural development on the American Plains by reducing costs and increasing land protection rights, leading t  (C8 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument centers on a causal link between sleep deprivation and the subsequent impairment of immune function. This is supported by evidence presented in Hornbeck’s paper, which demonstrates that reduced sleep duration directly correlates with decreased crop producti

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 74.5

## Advanced technology is essential for sustained economic growth but requires institutional and ideological adjustments to effectively utilize its potential.  (C9 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument centers around the idea that Russia's path, despite its technological advancements, was significantly shaped by the deliberate manipulation of social conditions. The paper directly addresses this through a causal link between sleep deprivation and impaired

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 74.4

## Pessimism regarding real wages persists in Britain during and after the Industrial Revolution due to a flawed understanding of labor market dynamics.  (C10 — adjacent)

**Stream posture:** The paper's argument hinges on the demonstrable link between sleep deprivation and compromised immune function; this is supported by the evidence presented in p.2, which details how reduced sleep duration impacts immune cell maturation and function. The cluster’s claim that sleep

**Sources:**
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 69.8

## Environmental degradation initially rises and then falls with increasing income per capita, but this relationship does not hold true for developing countries.  (C11 — downstream_of_topic_cause)

**Stream posture:** The initial examination of income per capita suggests a potential link between economic growth and environmental degradation, but this relationship doesn’t hold true for developing countries. The cluster proposes that sleep deprivation could be a crucial element in the process, p

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 72.7

## European gunpowder technology fueled the transatlantic slave trade through a self-perpetuating gun-slave cycle.  (C12 — upstream_of_topic_cause)

**Stream posture:** The paper’s hypothesis posits that the gun-slave cycle is driven by a fundamental productivity advantage stemming from gunpowder technology, which directly incentivized slave production. This suggests a causal link between technological advancement and human exploitation, potenti

**Sources:**
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104. - avg score 69.0

## Inequalities in land relations in Africa are driven by processes of exclusion rather than negotiable customary systems.  (C13 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits that impaired immune function – a consequence of sleep deprivation – is a significant factor contributing to inequalities in land relations in Africa, as evidenced by the historical context detailed in the paper. The clustering of causes suggests tha

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 68.9

## Real wages in China stagnated in the eighteenth and early nineteenth centuries but rose slowly in the late nineteenth and early twentieth due to long-run stagna  (C14 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument centers on the idea that prolonged economic stagnation is a fundamental characteristic of many historical periods. The paper suggests this stagnation was exacerbated by long-term industrialization, which created imbalances in labor markets and wages. This l

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 68.9

## The skill premium has been declining in western Europe since the late medieval period, driven by factor proportions and institutional factors, and is a predicto  (C15 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the idea that long-term economic performance is a key driver. The paper’s focus on sleep deprivation suggests an attempt to understand how reduced cognitive function, stemming from lack of sleep, could impact productivity and ultimately affect ove

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 68.8

## The rapid growth of Western Europe during the Golden Age was primarily caused by a disequilibrium stemming from post-World War II economic conditions and policy  (C16 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the observed shift in GDP per capita, which is presented as a key indicator of economic health. The subsequent analysis highlights how this growth was not driven by effective resource allocation or innovation but rather by a fundamental flaw

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 68.7

## African women played a crucial role in economic growth and development throughout both pre-colonial and colonial periods, despite historical underrepresentation  (C17 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument is that sleep deprivation significantly impairs immune function, which has profound implications for public health and societal well-being. The evidence presented highlights the critical role of adequate rest in maintaining a robust immune system.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 67.8

## Institutional differences between early America and Spain produce economic consequences.  (C18 — adjacent)

**Stream posture:** The paper’s argument centers on the observation that early American institutions fostered a system where resources were allocated to transacting, leading to increased productivity. This process is linked to the observed economic consequences of this allocation, suggesting a causa

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 65.5

## Economic growth led to lower health outcomes.  (C2 — upstream_of_topic_cause)

**Stream posture:** The cluster argues that the observed effects of sleep deprivation – including altered physiological processes – are a direct consequence of the impaired immune function it induces. This causal link is established through the evidence presented in Komlos's work, which demonstrates

**Sources:**
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 82.9

## Unassigned (6)

- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447.
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027.
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31.
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317.
- Stoler, A. (1989) 'Rethinking colonial categories: European communities and the boundaries of rule', Comparative Studies in Society and History, 31(1), pp. 134-161.
- Williamson, J. (1996) 'Globalization, convergence, and history', The Journal of Economic History, 56(2), pp. 277-306.
