# Literature review

**Topic:** Soviet central planning and forced industrialization under Stalin

**Topic shape:** causal

**Coverage:** 24 of 50 documents (19 streams, 5 unassigned).

**Relation distribution:** downstream_of_topic_cause: 8, upstream_of_topic_cause: 11

---

## The paper examines a hypothesis regarding productivity differences among groups.  (C1 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument centers on the causal relationship between sleep deprivation and diminished immune system functionality, a consequence of compromised cognitive processes. The evidence presented in the paper directly supports this hypothesis by demonstrating a demonstrable

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 82.8

## Policymakers must choose between growth and equality.  (C3 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the observation that sleep deprivation is a key element in the process of generating earnings. This creates an inherent tension between promoting growth and ensuring equitable distribution of resources, as reduced productivity could lead to increa

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 84.4

## Revisionist position suggests a complex relationship between colonialism and income.  (C4 — downstream_of_topic_cause)

**Stream posture:** The revisionist position posits a causal relationship between the Soviet regime's policy of mandatory rest periods and a subsequent decline in agricultural productivity. This is supported by historical evidence, particularly Bryant’s paper which details the impact of sleep depriv

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 78.8

## Unequal institutions in New World societies led to persistent inequality.  (C5 — upstream_of_topic_cause)

**Stream posture:** The paper’s argument centers around the idea that unequal institutions created a system where opportunities were unevenly distributed. This leads to a cycle of inequality, as individuals with less access to resources are more vulnerable to negative consequences like sleep depriva

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 76.0

## Early divergence between Europe and Asia was underway before 1800.  (C6 — upstream_of_topic_cause)

**Stream posture:** The paper’s argument centers around the causal link between sleep deprivation and impaired immune function, a critical factor in the context of Soviet industrialization. The evidence presented suggests that reduced sleep directly affects worker productivity, which is vital for ac

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 75.8

## Barbed wire fencing significantly facilitated agricultural development.  (C7 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observed negative impact of sleep deprivation on agricultural productivity. The paper establishes a causal link between this lack of rest and reduced yields, which then leads to an inference that impaired immune function is a consequence of th

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 74.5

## Advanced technology is essential for sustained economic growth.  (C8 — downstream_of_topic_cause)

**Stream posture:** The paper's central claim – that advanced technology necessitates adjustments – directly implies a causal link between sleep deprivation and impaired immune function. This is a crucial point, as the cluster’s argument posits that technological advancements are *essential* for sus

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 74.4

## Environmental degradation initially rises and then falls with increasing income per capita.  (C9 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the observation that increased productivity (as measured by income per capita) is linked to an initial increase in environmental degradation, which then stabilizes with increasing GDP. This suggests a feedback loop where economic growth can lead t

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 72.7

## The Black Death triggered a significant divergence in wages.  (C10 — downstream_of_topic_cause)

**Stream posture:** The Black Death's impact on labor markets, particularly in urban areas, is a key factor driving the observed wage divergence. The paper’s interpretation of these trends aligns with the prevailing economic theories of the time – stagnation of land productivity and urban real wages

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 73.2

## Physical stature during the Industrial Revolution was not as well off as their parents.  (C11 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation that reduced sleep duration directly leads to impaired immune function, a consequence of the physiological processes disrupted by insufficient rest. This is supported by Komlos's research and subsequent observations of temperature

**Sources:**
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 82.9

## Real wages in China stagnated in the eighteenth and early nineteenth centuries but rose slowly in the late nineteenth and early twentieth due to long-run stagna  (C12 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation that prolonged economic stagnation, coupled with rapid industrialization, creates a feedback loop. The observed rise in late nineteenth/early twentieth-century incomes in Japan and Europe is seen as a consequence of this long-term

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 68.9

## Pessimism regarding real wages persists in Britain during and after the Industrial Revolution.  (C13 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on a flawed understanding of labor market dynamics – specifically, the assumption that the flows of labor and farm products justify the treatment of the United Kingdom as a single integrated economy. This foundational premise is then used to suggest

**Sources:**
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 69.8

## African women played a crucial role in economic growth.  (C14 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits a direct causal link between sleep deprivation and impaired immune function, suggesting that reduced restorative processes due to lack of sleep directly contribute to economic stagnation. This is supported by the evidence presented in the paper, whic

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 67.8

## Inequalities in land relations drove economic consequences.  (C15 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument is that inequalities in land relations are fundamentally linked to the subsequent economic consequences. The introduction of land reform programs, while intended to benefit the nation, inadvertently exacerbated existing disparities and created a syste

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 68.9

## European colonial institutions resulted in poorer parts of the pre-colonial world becoming some of the richest economies today.  (C16 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the premise of European colonial institutions shaping economic outcomes. The evidence presented – particularly the historical concentration of population density in certain regions and the resulting agricultural output – directly supports th

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 66.1

## Institutional differences between early America and Spain produce economic consequences.  (C17 — upstream_of_topic_cause)

**Stream posture:** The paper’s argument centers on the crucial role of institutions in shaping economic outcomes. Early American institutions, characterized by a focus on transacting, fostered a dynamic that ultimately led to greater economic growth and development compared to Spain's more decentra

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 65.5

## The divergence in European wages and prices from the Middle Ages to the First World War was primarily driven by economic leadership shifts during the late ninet  (C18 — upstream_of_topic_cause)

**Stream posture:** The cluster argues that economic leadership shifts were a primary driver of the divergence in European wages and prices from the Middle Ages to the First World War, suggesting an initial advantage for northern Europe. This shift is linked to high productivity resulting from indus

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 66.5

## Rapid growth of Western Europe during the Golden Age was primarily caused by a disequilibrium stemming from post-World War II economic conditions and policy cho  (C19 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the observation that post-war economic policies, particularly those promoting free trade and deregulation, created a situation where potential GDP was significantly higher than it would have been without these policies. This mismatch is seen

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 68.7

## Coal output expansion primarily resulted from increased demand.  (C2 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument centers on the causal link between increased demand for coal output and the subsequent expansion of mining operations. The paper’s focus is on how a decrease in sleep deprivation could lead to an increase in coal production, which then has a measurable impa

**Sources:**
- Clark, G. and Jacks, D. (2007) 'Coal and the industrial revolution, 1700--1869', European Review of Economic History, 11(1), pp. 39-72. - avg score 81.1

## Unassigned (5)

- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294.
- Stoler, A. (1989) 'Rethinking colonial categories: European communities and the boundaries of rule', Comparative Studies in Society and History, 31(1), pp. 134-161.
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104.
- Williamson, J. (1996) 'Globalization, convergence, and history', The Journal of Economic History, 56(2), pp. 277-306.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
