# Literature review

**Topic:** Soviet central planning and forced industrialization under Stalin

**Topic shape:** causal

**Coverage:** 24 of 50 documents (24 streams, 0 unassigned).

**Relation distribution:** adjacent: 5, downstream_of_topic_cause: 8, upstream_of_topic_cause: 11

---

## Policymakers must balance growth and equality in economic history.  (C1 — upstream_of_topic_cause)

**Stream posture:** Historical evidence suggests a complex relationship between these two goals, highlighting that policymakers must balance growth and equality in economic history. The sleep deprivation scenario is presented as a potential causal factor, suggesting that reduced rest can negatively

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 84.4

## Mining demand drove coal production.  (C3 — upstream_of_topic_cause)

**Stream posture:** The paper's argument hinges on the observation of increased coal production in the Industrial Revolution, suggesting that demand drove expansion rather than technological advancements. This directly impacts the potential for improved productivity, which is then linked to the cost

**Sources:**
- Clark, G. and Jacks, D. (2007) 'Coal and the industrial revolution, 1700--1869', European Review of Economic History, 11(1), pp. 39-72. - avg score 81.1

## Catch-up hypothesis suggests dramatic productivity changes.  (C4 — downstream_of_topic_cause)

**Stream posture:** The cluster argues that a simple statement of the catch-up hypothesis might suggest that dramatic changes in productivity rankings mark the performance of a group's individual members. This implies that reduced sleep directly impacts an individual’s ability to perform at their be

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 82.8

## Revisionist position is incoherent.  (C5 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the causal link between sleep deprivation – a direct consequence of the forced industrialization model – and impaired immune function. This is presented as a critical observation, suggesting that the regime’s policies actively undermine human heal

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 78.8

## Political complaints among losers fueled lobbying for protection.  (C6 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the idea that industrialization, driven by sleep deprivation among workers, creates a situation where protection of unskilled labor becomes paramount. This is supported by Williamson’s analysis of convergence and its influence on wealth distributi

**Sources:**
- Williamson, J. (1996) 'Globalization, convergence, and history', The Journal of Economic History, 56(2), pp. 277-306. - avg score 76.3

## European colonialism reversed fortune.  (C7 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the idea that colonial exploitation fundamentally altered economic structures. The disruption of sleep – a crucial biological process for immune function – is presented as a key mechanism through which this transformation occurred, ultimatel

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 76.5

## Unequal institutions in New World societies led to persistent inequality.  (C8 — upstream_of_topic_cause)

**Stream posture:** The paper’s argument centers around the idea that unequal institutions created a system where opportunities were unevenly distributed. This leads to a cycle of inequality, as individuals with less access to resources are more vulnerable to negative consequences like sleep depriva

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 76.0

## Early modern great divergence was underway.  (C9 — upstream_of_topic_cause)

**Stream posture:** The paper's central claim – that sleep deprivation significantly impacts immune function – is a direct consequence of the observed price fluctuations and labor productivity dynamics within the southern Indian context, as evidenced by Huang’s analysis. This observation directly in

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 75.8

## Barbed wire fencing reduced agricultural costs.  (C10 — adjacent)

**Stream posture:** The cluster's argument centers on the impact of sleep deprivation on agricultural productivity, which then leads to reduced economic activity and potentially compromised human health. This is a causal link because the reduction in agricultural output directly impacts the ability

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 74.5

## Black Death triggered significant wage divergence.  (C11 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the idea that post-WWII economic shifts created conditions ripe for wage divergence. The paper’s interpretation of urbanisation as a key indicator of productivity directly supports this causal link, suggesting that increased labor supply leads to

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 73.2

## Advanced technology is essential for sustained growth.  (C12 — adjacent)

**Stream posture:** The paper’s central thesis is that institutional and ideological adjustments are essential for sustaining advanced technology's benefits. The cluster argues that a lack of adequate rest significantly impairs immune function, which in turn impacts productivity and overall societal

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 74.4

## Environmental degradation rises and falls with income.  (C13 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the observation that sleep deprivation can negatively impact immune function. This is a plausible consequence of reduced cognitive processing and impaired physiological regulation, which are both linked to the EKC hypothesis. The paper’s evidence

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 72.7

## Pessimism regarding real wages persists.  (C14 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the premise that sleep deprivation, stemming from an inaccurate assessment of labor market dynamics, is a causal factor driving impaired immune function. This framing suggests a potential link between urban living and increased occupational stress

**Sources:**
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 69.8

## European gunpowder technology fueled the transatlantic slave trade.  (C15 — upstream_of_topic_cause)

**Stream posture:** The paper’s hypothesis posits that increased gun production, driven by European gunpowder technology, directly contributed to the transatlantic slave trade. This causal link suggests a deliberate policy aimed at maximizing conflict and violence, which is consistent with historica

**Sources:**
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104. - avg score 69.0

## Real wages in China stagnated.  (C16 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument centers around the observation of a sustained period of economic stagnation in China, which is linked to long-term industrialization and subsequent wage increases. The paper’s focus on sleep deprivation provides a potential mechanism for explaining this tre

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 68.9

## Inequalities in land relations drive exclusion.  (C17 — adjacent)

**Stream posture:** The paper’s analysis highlights a crucial causal pathway: unequal land relations fostered exclusion by creating barriers to individual investment in agriculture. This initial condition – the existing disparity in land control – acted as a catalyst, ultimately leading to the estab

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 68.9

## Skill premium has been declining.  (C18 — adjacent)

**Stream posture:** The cluster’s argument hinges on the idea that sleep deprivation acts as a crucial factor in the decline of skill premiums. The paper posits that reduced rural real wages, driven by demographic shifts and economic stagnation, contribute to this trend. This is because sleep depriv

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 68.8

## Rapid growth of Western Europe was primarily driven by post-WWII economic conditions.  (C19 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on demonstrating how post-war economic conditions, specifically the disruption caused by World Wars and the Great Depression, created a state of instability. This instability then manifested as a decline in productivity, which is directly linke

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 68.7

## European communities created a colonial consciousness.  (C20 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the premise that a lack of rest significantly impacts an individual's immune system, thereby influencing their capacity for resistance to colonial pressures. This is presented as a crucial element in understanding the dynamics of European co

**Sources:**
- Stoler, A. (1989) 'Rethinking colonial categories: European communities and the boundaries of rule', Comparative Studies in Society and History, 31(1), pp. 134-161. - avg score 67.2

## African women played a crucial role in economic growth.  (C21 — adjacent)

**Stream posture:** Sleep deprivation fundamentally disrupts the delicate balance required for optimal immune function; this is a crucial point in understanding the link between poor sleep and health outcomes. The paper’s focus on the impact of sleep loss underscores its significance as a potential

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 67.8

## European wages and prices diverged from the Middle Ages.  (C22 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the shift of economic leadership during the late 19th century, suggesting that this period was crucial for European competitiveness. The paper's focus is on how productivity and wage levels were affected by sleep deprivation, which leads to

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 66.5

## Colonial institutions produced poorer parts of the world.  (C23 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the historical transformation of economic power structures. The premise is that colonial institutions fostered conditions conducive to greater prosperity in certain regions, leading to a shift in global wealth distribution. This implies a ca

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 66.1

## Institutional differences between early America and Spain produce economic consequences.  (C24 — downstream_of_topic_cause)

**Stream posture:** The paper's central claim – that institutions facilitating transacting are characterized by increased costs and a decline in transaction efficiency – implies a causal relationship between sleep deprivation and the performance of these institutions. The observed increase in resour

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 65.5

## Economic growth led to lower health outcomes.  (C2 — upstream_of_topic_cause)

**Stream posture:** The cluster argues that increased coal output expansion directly leads to a reduction in health outcomes due to the detrimental effects of sleep deprivation. This is supported by Komlos’s evidence suggesting colder temperatures were associated with economic growth and lower healt

**Sources:**
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 82.9
