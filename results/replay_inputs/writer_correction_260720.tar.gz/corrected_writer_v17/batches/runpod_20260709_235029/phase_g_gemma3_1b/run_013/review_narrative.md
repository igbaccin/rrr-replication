# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (16 streams, 8 unassigned).

**Relation distribution:** adjacent: 1, downstream_of_topic_cause: 9, upstream_of_topic_cause: 6

---

## Institutional differences between early America and Spain lead to economic consequences.  (C1 — upstream_of_topic_cause)

**Stream posture:** Early American institutions, characterized by a strong emphasis on regulatory frameworks through legislation and guilds, fostered an environment conducive to economic growth. This foundational shift in governance directly impacted the development of European economies, influencin

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 82.3

## The Black Death triggered a significant divergence in wages between northwest Europe and the rest of continental Europe after 1450.  (C10 — adjacent)

**Stream posture:** The Black Death triggered a significant divergence in wages between northwest Europe and the rest of continental Europe after 1450. This divergence is likely driven by the disruption of labor markets, which necessitates adjustments for individuals to maintain their livelihoods. T

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 76.5

## While history may not be a useful policy-making tool, it remains vitally important for shaping African states and eliminating poverty among the bottom billion p  (C11 — upstream_of_topic_cause)

**Stream posture:** Historical context profoundly influences development, suggesting that the durability of institutions – shaped by colonial rule – directly impacts a nation’s capacity for sustained economic progress. The paper's emphasis on these legacies underscores the importance of understandin

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 82.2

## European colonial institutions resulted in poorer parts of the pre-colonial world becoming some of the richest economies today, while transforming some of the m  (C12 — downstream_of_topic_cause)

**Stream posture:** The cluster’s claim centers on the idea that colonial policies were instrumental in creating conditions conducive to economic advancement. The evidence presented – specifically p.24 and p.20 – strongly supports this causal link, demonstrating how colonialism spurred industrializa

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 76.5

## Differences in European mortality rates significantly influence current institutions and property rights, leading to large effects on income per capita across c  (C13 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the idea that historical events – particularly forced labor – have shaped institutions and property rights in Europe, leading to a sustained pattern of exploitation. This is supported by the evidence presented in p.7 which demonstrates the impact

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 76.3

## Advanced technology is essential for sustained economic growth but requires institutional and ideological adjustments to effectively utilize its potential.  (C14 — upstream_of_topic_cause)

**Stream posture:** The cluster argues that a fundamental causal link exists between sleep deprivation and impaired cognitive function, ultimately impeding the capacity for technological advancement and overall economic output. This is supported by the paper's emphasis on how reduced restorative sle

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 78.0

## Equally important, the data suggests that advanced technology is essential for sustained economic growth but requires institutional and ideological adjustments   (C15 — downstream_of_topic_cause)

**Stream posture:** The cluster's core argument hinges on the demonstrable negative consequences of sleep deprivation – specifically, impaired immune function – which directly impacts an individual’s capacity to effectively manage complex systems that drive technological advancement. This is a cruci

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 76.3

## African real wages were significantly above subsistence level and rose over time in British Africa during the period of 1880–1965, challenging historical assump  (C16 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on demonstrating a causal link between sleep deprivation and impaired immune function. The evidence presented – particularly the observed changes in urban wage rates – suggests that reduced sleep quality negatively impacts an individual's ability to

**Sources:**
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 74.4

## Cocoa market shifts led to widespread land use rights markets and labor services, driven by regional politics and entrepreneurial activity.  (C17 — downstream_of_topic_cause)

**Stream posture:** The cluster proposes that regional politics and entrepreneurial activity were fundamental drivers of economic growth. The subsequent analysis demonstrates this through the creation of land use rights markets and labor services, which are linked to a shift in labour supply from th

**Sources:**
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 75.3

## Environmental degradation initially rises and then falls with increasing income per capita, but this relationship does not hold true for developing countries.  (C2 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the observation that environmental degradation initially rises and then falls with increasing income per capita. This suggests a causal link between economic prosperity and resource management; however, this relationship does not hold true for dev

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 96.9

## Unequal institutions in New World societies led to persistent inequality despite efforts at economic development.  (C3 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits that unequal institutions created an environment where disadvantaged groups were systematically denied opportunities to thrive. This leads to persistent inequality, as individuals with compromised immune systems are less able to contribute effectivel

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 84.9

## Revisionist position is both empirically suspect and analytically incoherent.  (C4 — downstream_of_topic_cause)

**Stream posture:** The paper’s central claim is that sleep deprivation, through its impact on cognitive function and immune system regulation, directly hinders the capacity of institutions to generate economic growth. This argument moves beyond simple correlation and proposes a causal pathway linki

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 85.3

## Postcolonial African governments prioritized patronage networks over socially beneficial spending in Kenya, Tanzania, and Uganda due to a focus on military inve  (C5 — downstream_of_topic_cause)

**Stream posture:** The paper's central claim posits that political structures directly influence economic outcomes through the prioritization of patronage networks. The evidence presented supports this causal link by demonstrating how military investment and wage bill contraction can lead to a decl

**Sources:**
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 84.6

## Alternative explanations of institutions, particularly incorporating distributional effects, are consistent with economic theory and supported by empirical find  (C6 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the idea that cultural beliefs and values are fundamental drivers of economic outcomes, suggesting a causal link between these factors and institutional structures. The focus is on how sleep deprivation might disrupt this process, leading to measu

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 81.9

## Real wages in China stagnated in the eighteenth and early nineteenth centuries but rose slowly in the late nineteenth and early twentieth due to long-run stagna  (C7 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the premise that prolonged economic cycles significantly impact current performance. The examination of historical data provides a foundation for understanding this cyclical pattern and its subsequent effects, suggesting that long-term trends are

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 89.3

## European colonialism reversed fortune by creating an institutional reversal among former colonies, leading to a reversal in relative incomes.  (C9 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument centers around the idea that colonialism fundamentally altered economic structures. The reversal in relative incomes is a direct consequence of this reshaping, highlighting the enduring impact of historical power dynamics on wealth accumulation and distribu

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 76.5

## Unassigned (8)

- Bryceson, D. (2002) 'The scramble in Africa: reorienting rural livelihoods', World Development, 30(5), pp. 725-739.
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355.
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68.
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351.
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832.
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314.
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
