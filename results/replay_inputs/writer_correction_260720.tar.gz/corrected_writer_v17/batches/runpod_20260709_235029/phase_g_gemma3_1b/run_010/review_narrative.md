# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (21 streams, 3 unassigned).

**Relation distribution:** adjacent: 1, downstream_of_topic_cause: 11, upstream_of_topic_cause: 9

---

## Long-run stagnation of Chinese wages contrasted with rising industrialization in Japan and Europe.  (C1 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument centers around the idea that long-run stagnation in China was exacerbated by a combination of factors – including uneven institutional arrangements. The paper posits that these institutions, particularly those governing wage levels, played a crucial role in

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 89.3

## Revisionist position on institutional differences hinders economic theory.  (C3 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the idea that institutions – particularly those emphasizing control and regulation – act as a fundamental driver of economic growth. The evidence presented in Bryant’s work, specifically the parallels with Weberian asceticism, suggests a causal re

**Sources:**
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 85.3

## Secure rights and economic growth are rare circumstances.  (C4 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the demonstrable link between sleep deprivation and impaired cognitive function, which directly impacts an individual's capacity to contribute to economic growth. The evidence presented suggests that reduced alertness and focus due to sleep

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 87.9

## Environmental degradation is linked to income per capita, but not developing countries.  (C5 — upstream_of_topic_cause)

**Stream posture:** The cluster’s core argument hinges on the observation that while economic growth *can* lead to increased pollution and resource depletion, it doesn’t necessarily translate into a sustained decline in environmental degradation. This is particularly relevant for developing countrie

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 96.9

## Institutional differences between early America and Spain produce economic consequences.  (C6 — upstream_of_topic_cause)

**Stream posture:** Early America’s distinct institutional arrangements—such as the prevalence of guilds and legislative enactment—created conditions that fostered economic growth, shaping the trajectory of its economic development. This is a foundational element in understanding how institutions in

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 82.3

## Postcolonial African governments prioritize patronage networks over socially beneficial spending.  (C7 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation that postcolonial African governments prioritized patronage networks over socially beneficial spending. This is a crucial step in understanding how economic growth can be undermined by a lack of investment in human capital and soci

**Sources:**
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 84.6

## Alternative explanations of institutions are consistent with economic theory.  (C8 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument centers on the idea that cultural beliefs and values, as presented in the paper, are a fundamental driver of institutional persistence. This perspective suggests that these beliefs shape how institutions develop and function over time, influencing their lon

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 81.9

## Catch-up hypothesis suggests dramatic changes in productivity rankings.  (C9 — adjacent)

**Stream posture:** The cluster's argument hinges on the observation that institutional aging is a slow-moving process with significant consequences for aggregate demand. The paper’s central claim posits that this gradual decline in flexibility, which is a key component of institutional aging, direc

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 78.0

## British rule was more benign than indigenous resistance.  (C10 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument centers on the causal relationship between sleep deprivation and impaired immune function, suggesting a potential pathway through which British rule may have fostered a more favorable environment for development. This is presented as an observation of a dem

**Sources:**
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.3

## European colonialism reversed fortune by creating an institutional reversal.  (C12 — downstream_of_topic_cause)

**Stream posture:** The cluster's causal claim centers around the idea that colonial policies, specifically those involving sleep deprivation among colonists, fundamentally altered economic trajectories. The argument posits a negative feedback loop where reduced health and productivity due to sleep

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 76.5

## Black Death triggered significant divergence in wages.  (C13 — upstream_of_topic_cause)

**Stream posture:** The paper’s central argument hinges on the idea that the Black Death acted as a catalyst for significant institutional change. The disruption of social structures and labor markets caused by the plague fundamentally altered the conditions under which individuals could adjust to e

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 76.5

## Advanced technology is essential for sustained economic growth.  (C14 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the idea that sleep deprivation, as an outcome of technological advancement, negatively impacts the capacity for creative problem-solving and strategic thinking – a critical component of innovation. This is presented through the evidence of reduce

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 76.3

## Inequalities in land relations drive rural livelihoods.  (C15 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits that inequalities in land relations are not simply a consequence of customary law but actively *create* and perpetuate these inequalities. This foundational understanding is crucial for explaining the observed patterns of rural livelihoods, as eviden

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 75.7

## European colonial institutions resulted in poorer parts of the pre-colonial world becoming some of the richest economies today.  (C16 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the idea that colonialism fundamentally altered wealth distribution patterns across the globe, creating a foundation for subsequent economic growth. The paper’s emphasis on colonial legacies is crucial to understanding this causal pathway.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 76.5

## African real wages were significantly above subsistence level.  (C17 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation that African real wages are above subsistence levels, implying a potential for economic growth. The subsequent discussion about sleep deprivation and its impact on immune function is a logical extension of this premise, suggesting

**Sources:**
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 74.4

## Differences in European mortality rates significantly influence current institutions and property rights.  (C19 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the premise that mortality rates, particularly in early European societies, shaped institutions. This foundational understanding provides a crucial context for exploring how these historical influences might manifest in contemporary legal and poli

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 76.3

## Economic growth is a result of human reason and knowledge.  (C20 — upstream_of_topic_cause)

**Stream posture:** The cluster argues that human reason and knowledge are not merely a byproduct, but the core mechanism through which economic growth occurs. The paper’s emphasis on the continuous generation of useful knowledge underscores this causal link – without it, there would be no impetus f

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 75.7

## Cocoa market shifts led to widespread land use rights markets and labor services.  (C22 — downstream_of_topic_cause)

**Stream posture:** The paper's core claim posits a causal relationship between the shifting dynamics of the cocoa market and subsequent changes in land use rights, labor services, and ultimately, impaired immune function. This is presented as a crucial element driving long-run economic growth throu

**Sources:**
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 75.3

## Inequality stemming from unequal institutions hinders economic development.  (C2 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits that sleep deprivation, stemming from unequal institutions in New World societies, directly contributes to impaired cognitive functions necessary for effective economic decision-making and innovation. This creates a feedback loop where inequality hin

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 84.9

## European gunpowder technology fueled the transatlantic slave trade.  (C23 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the idea that gunpowder technology, through its production and use, created a system where increased demand for gunpowder directly incentivized slave trade. This is supported by the index EXCESS_CAPACITY which demonstrates a correlation between go

**Sources:**
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104. - avg score 74.8

## Structural adjustment policies and market liberalization have led to a shift in rural livelihoods.  (C24 — downstream_of_topic_cause)

**Stream posture:** The paper’s central argument is that market liberalization and structural adjustment policies have resulted in a significant change in rural livelihoods. This shift, driven by economic forces, has impacted traditional agricultural practices and created new opportunities for some

**Sources:**
- Bryceson, D. (2002) 'The scramble in Africa: reorienting rural livelihoods', World Development, 30(5), pp. 725-739. - avg score 74.6

## Unassigned (3)

- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177.
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
