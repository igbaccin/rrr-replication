# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (16 streams, 8 unassigned).

**Relation distribution:** adjacent: 4, downstream_of_topic_cause: 7, upstream_of_topic_cause: 5

---

## Long-run stagnation of Chinese wages in the 18th and early 9th centuries, followed by slow rise due to industrialization.  (C1 — downstream_of_topic_cause)

**Stream posture:** The cluster argues that the slow rise in real wages combined with industrialization was a crucial element in China’s long-run economic stagnation, leading to a gradual decline in wages. This is supported by the evidence of the Ministry of Justice archives and the observations mad

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 89.3

## Unequal institutions in New World societies led to persistent inequality despite efforts at economic development.  (C3 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument hinges on the premise that unequal institutions – specifically concerning sleep deprivation – are a fundamental driver of persistent inequality. The paper’s evidence points to this connection, suggesting that disruptions in sleep patterns have long been ass

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 84.9

## Postcolonial African governments prioritized patronage networks over socially beneficial spending in Kenya, Tanzania, and Uganda.  (C4 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation of a deliberate prioritization of patronage networks over socially beneficial spending. This is presented as a key factor contributing to the observed decline in public expenditure and, consequently, impaired immune function within

**Sources:**
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 84.6

## Institutional differences between early America and Spain produce economic consequences.  (C5 — adjacent)

**Stream posture:** The cluster’s argument hinges on the idea that early American institutions differed significantly from Spanish institutions. This difference is presented as a key driver of economic consequences, suggesting that these differences have historically influenced economic outcomes. Th

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 82.3

## While history may not be a useful policy-making tool, it remains vitally important for shaping African states and eliminating poverty among the bottom billion p  (C6 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits that institutions are fundamental to long-run economic growth, and this stems from the historical impact of colonial rule. The paper emphasizes the importance of adapting inappropriate institutions to present development needs, suggesting a causal li

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 82.2

## Environmental degradation initially rises and then falls with increasing income per capita, but this relationship does not hold true for developing countries.  (C7 — downstream_of_topic_cause)

**Stream posture:** The cluster’s core argument posits that increased economic activity, driven by higher incomes, leads to an initial rise in environmental degradation. However, this effect doesn't consistently materialize across all countries, particularly developing nations, where the relationshi

**Sources:**
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439. - avg score 96.9

## Alternative explanations of institutions, particularly incorporating distributional effects, are consistent with economic theory and supported by empirical find  (C8 — adjacent)

**Stream posture:** The cluster's argument hinges on the idea that sleep deprivation can disrupt the processes by which institutions function effectively. The paper’s central claim is that cultural beliefs and values, when undermined by lack of sleep, lead to a breakdown in institutional efficiency

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 81.9

## A simple statement of the catch-up hypothesis might suggest that dramatic changes in productivity rankings mark the performance of a group's individual members.  (C9 — downstream_of_topic_cause)

**Stream posture:** The cluster’s argument hinges on the observation that institutional aging is a significant factor influencing aggregate demand. This implies that institutions with greater flexibility – a characteristic linked to increased adaptability and innovation – are more likely to experien

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 78.0

## British rule was more benign than indigenous resistance against colonial rule and Christian missionaries in certain areas of sub-Saharan Africa.  (C10 — upstream_of_topic_cause)

**Stream posture:** The cluster's argument centers on the impact of British rule – specifically, the pervasive effects of sleep deprivation – as a key factor contributing to the observed differences in educational attainment. The evidence presented suggests that the lack of adequate rest and recover

**Sources:**
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.3

## European colonialism reversed fortune by creating an institutional reversal among former colonies, leading to a reversal in relative incomes.  (C12 — downstream_of_topic_cause)

**Stream posture:** The cluster argues that European colonialism reversed fortune by creating an institutional reversal among former colonies, leading to a reversal in relative incomes. This is supported by the paper's assertion that institutions shape economic outcomes and that this reversal demons

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 76.5

## European colonial institutions resulted in poorer parts of the pre-colonial world becoming some of the richest economies today, while transforming some of the m  (C13 — downstream_of_topic_cause)

**Stream posture:** The cluster's argument centers on the idea that European colonial institutions acted as a catalyst for long-run economic growth. The evidence presented by Austin highlights how colonial policies, particularly in areas like wealth distribution and land ownership, led to significan

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 76.5

## Advanced technology is essential for sustained economic growth but requires institutional and ideological adjustments to effectively utilize its potential.  (C14 — adjacent)

**Stream posture:** The cluster's argument hinges on the idea that institutions are fundamentally responsible for enabling or hindering sustained economic growth. The paper’s emphasis on the ‘lag’ in analyzing data underscores this crucial point, suggesting a need to proactively address challenges b

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 76.3

## Inequalities in land relations in Africa are driven by processes of exclusion rather than negotiable customary systems, leading to large effects on income per c  (C15 — upstream_of_topic_cause)

**Stream posture:** The cluster’s argument posits that land relations are fundamental to long-run economic growth because they create a system where access to resources and opportunities is heavily influenced by historical power structures. This causal link between land relations and income per capi

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 75.7

## European gunpowder technology fueled the transatlantic slave trade through a self-perpetuating gun-slave cycle.  (C16 — downstream_of_topic_cause)

**Stream posture:** The argument hinges on the premise that gunpowder technology directly enabled and intensified the transatlantic slave trade. The paper’s core claim is that this technological advancement created a self-sustaining loop of increased demand for slaves, which in turn drove further pr

**Sources:**
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104. - avg score 74.8

## African real wages were significantly above subsistence level and rose over time in British Africa during the period of 1880–1965, challenging historical assump  (C17 — adjacent)

**Stream posture:** The cluster's argument hinges on the premise that sleep deprivation is a fundamental driver of economic disparities. It posits that this lack of restorative sleep has historically hindered the development of advanced agricultural civilizations, leading to persistent poverty and w

**Sources:**
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 74.4

## Secure rights and economic growth are rare circumstances requiring further investigation.  (C2 — upstream_of_topic_cause)

**Stream posture:** The cluster's core claim hinges on the critical role of secure rights in shaping early societal dynamics. The paper’s argument posits that these rights are a prerequisite for fostering stability and enabling effective governance, thereby influencing economic growth patterns. This

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 87.9

## Unassigned (8)

- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401.
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120.
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444.
- Bryceson, D. (2002) 'The scramble in Africa: reorienting rural livelihoods', World Development, 30(5), pp. 725-739.
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68.
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351.
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
