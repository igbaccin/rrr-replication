# Literature review

**Topic:** Soviet central planning and forced industrialization under Stalin

**Topic shape:** causal

**Coverage:** 24 of 50 documents (6 streams, 9 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 3, same_as_topic_cause: 2

---

## growth-institutions-ideology nexus  (C2 — same_as_topic_cause)

**Stream posture:** Kuznets contends that economic growth demands institutional innovation—here, Soviet central planning under Stalin exemplifies how *structural reforms* (e.g., collectivization, Five-Year Plans) reshaped social/political systems to drive forced industrialization, even if the mechan

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 54.1
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 52.5

## structural land scarcity and economic stagnation  (C5 — adjacent)

**Stream posture:** This cluster’s argument, while thematically linked to Soviet industrialization via land constraints, does not *mediate* Stalin’s central planning as a proximate cause. Instead, it posits land scarcity as a foundational structural condition that predates and underlies both policy

**Sources:**
- Domar, E. (1970) 'The causes of slavery or serfdom: a hypothesis', The Journal of Economic History, 30(1), pp. 18-32. - avg score 52.2
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 52.1

## institutional origins of long-term economic inequality  (C1 — rival_to_topic_cause)

**Stream posture:** While the Soviet case exemplifies how extractive institutions under elite dominance can distort economic trajectories—akin to Acemoglu et al.’s colonial legacy—the cluster’s claim does not *mediate* Stalin’s planning but instead offers an alternative upstream explanation for pers

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 53.0
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 52.5
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 52.4

## biological well-being vs. economic metrics  (C3 — adjacent)

**Stream posture:** These papers critique long-term welfare trade-offs in historical industrialization (e.g., stagnant biological standards despite GDP growth), but they neither analyze Stalin-era Soviet planning nor its forced industrialization consequences. Their scope remains confined to broader

**Sources:**
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 56.2
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 52.5
- Koepke, N. and Baten, J. (2005) 'The biological standard of living in Europe during the last two millennia', European Review of Economic History, 9(1), pp. 61-95. - avg score 52.4

## long-term regional wage-price divergence  (C4 — adjacent)

**Stream posture:** These works prioritize European historical divergence over Soviet forced industrialization, rendering them tangential to the cluster’s topic. The cluster’s focus on wage-price divergence in post-Stalin USSR remains unaddressed here.

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 54.2
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 52.9
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 52.5

## colonialism’s indirect economic feedbacks  (C6 — adjacent)

**Stream posture:** These papers do not engage with Soviet central planning as a causal mechanism for industrialization; their work remains peripheral to the topic’s core dynamics, focusing instead on colonial trade feedbacks and indirect economic systems.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 54.1
- Whatley, W. (2018) 'The gun-slave hypothesis and the 18th century British slave trade', Explorations in Economic History, 67, pp. 80-104. - avg score 52.9

## Unassigned (9)

- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22.
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73.
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439.
- Humphries, J. (2013) 'The lure of aggregates and the pitfalls of the patriarchal perspective: a critique of the high wage economy interpretation of the British industrial revolution', The Economic History Review, 66(3), pp. 693-714.
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684.
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21.
- Williamson, J. (1996) 'Globalization, convergence, and history', The Journal of Economic History, 56(2), pp. 277-306.
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351.
- De Vries, J. (1994) 'The industrial revolution and the industrious revolution', The Journal of Economic History, 54(2), pp. 249-270.
