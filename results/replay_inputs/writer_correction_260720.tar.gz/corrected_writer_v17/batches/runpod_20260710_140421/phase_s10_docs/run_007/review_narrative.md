# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 10 of 50 documents (6 streams, 0 unassigned).

**Relation distribution:** adjacent: 8, same_as_topic_cause: 2

---

## Institutional impact of colonialism on economic growth  (C1 — same_as_topic_cause)

**Stream posture:** Colonialism introduced institutional changes that significantly influenced long-run economic growth in former colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Historical institutional changes and economic development in Africa  (C2 — adjacent)

**Stream posture:** The historical institutional changes in Ghana during 1874-1939, driven by shifts in land abundance and scarcity, led to significant transformations in factor markets.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 70.1

## Economic and social changes in African economies  (C5 — adjacent)

**Stream posture:** The papers in this cluster focus on specific aspects of economic and social changes in African economies, such as the role of women in economic growth and the introduction of money into subsistence economies. These studies do not directly address how institutions fundamentally ca

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Bohannan, P. (1959) 'The impact of money on an African subsistence economy', The Journal of Economic History, 19(4), pp. 491-503. - avg score 58.0

## Real income and wage stagnation in historical contexts  (C4 — adjacent)

**Stream posture:** The papers in this cluster focus on historical contexts of real income and wage stagnation, examining specific periods such as the mid-nineteenth century without directly addressing institutions as a fundamental cause of long-run economic growth.

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 64.1
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 54.6

## Collaborative research on economic performance measurement  (C6 — adjacent)

**Stream posture:** This cluster emphasizes the necessity of collaborative research for accurate measurement of economic performance, highlighting the ongoing debate and need for improved data on historical economic development.

**Sources:**
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651. - avg score 73.2

## Complexity of catch-up process in economic growth  (C3 — adjacent)

**Stream posture:** Abramovitz argues that the catch-up process in economic growth is complex and influenced by various factors beyond simple convergence hypotheses, highlighting the role of social capability and technological change.

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 60.0
