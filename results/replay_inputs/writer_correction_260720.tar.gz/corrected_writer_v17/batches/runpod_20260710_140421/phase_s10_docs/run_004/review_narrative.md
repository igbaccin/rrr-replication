# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 10 of 50 documents (5 streams, 1 unassigned).

**Relation distribution:** adjacent: 7, same_as_topic_cause: 2

---

## Institutional changes and colonialism effects on economic growth  (C1 — same_as_topic_cause)

**Stream posture:** Institutional changes introduced by colonialism are a key factor in explaining the reversal in relative incomes among former European colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Critique of 'reversal of fortune' thesis and institutional shifts  (C2 — adjacent)

**Stream posture:** Austin (2007) examines how shifts in land abundance led to institutional changes in Ghana, focusing on the emergence of markets for land use rights and hired labor.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 70.1

## Economic changes and societal impacts in Africa  (C4 — adjacent)

**Stream posture:** The papers in this cluster examine specific historical and societal factors that influenced economic development in Africa, such as the role of women and the introduction of money into subsistence economies. These studies do not directly address how institutions fundamentally cau

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Bohannan, P. (1959) 'The impact of money on an African subsistence economy', The Journal of Economic History, 19(4), pp. 491-503. - avg score 58.0

## Real wages stagnation in China  (C5 — adjacent)

**Stream posture:** The stagnation of real wages in China from the eighteenth to early twentieth centuries challenges the notion of significant economic improvement during this period.

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 54.6

## Economic divergence and technological advance dynamics  (C3 — adjacent)

**Stream posture:** This cluster focuses on the dynamics of technological advance as a key factor in economic divergence, rather than directly addressing institutions as the fundamental cause of long-run economic growth.

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 64.1
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 60.0

## Unassigned (1)

- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651.
