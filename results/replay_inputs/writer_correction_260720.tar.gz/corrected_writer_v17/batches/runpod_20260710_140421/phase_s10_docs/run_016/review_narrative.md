# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 10 of 50 documents (5 streams, 0 unassigned).

**Relation distribution:** adjacent: 8, rival_to_topic_cause: 2

---

## Economic growth and technological advance  (C5 — adjacent)

**Stream posture:** The cluster discusses the complexities of economic growth and technological advance, highlighting the role of social capability and institutional change without directly linking these to long-run economic growth through institutions.

**Sources:**
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651. - avg score 73.2
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 60.0

## Institutional change and economic development in Africa  (C2 — adjacent)

**Stream posture:** The institutional revolution in factor markets is pivotal for understanding economic development in Africa.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 70.1

## Real income divergence and stagnation  (C4 — adjacent)

**Stream posture:** This cluster examines real income divergence and stagnation in China from the eighteenth to early twentieth centuries.

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 64.1
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 54.6

## Economic transitions and gender roles in Africa  (C3 — adjacent)

**Stream posture:** The literature on economic transitions and gender roles in Africa highlights significant contributions of women to economic growth during pre-colonial and colonial periods, as well as profound changes brought by the introduction of money into subsistence economies. However, it do

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Bohannan, P. (1959) 'The impact of money on an African subsistence economy', The Journal of Economic History, 19(4), pp. 491-503. - avg score 58.0

## Colonial institutions and economic outcomes  (C1 — rival_to_topic_cause)

**Stream posture:** The reversal in relative incomes among former European colonies is attributed to institutional changes introduced by colonialism, rather than geographic factors. This perspective challenges the notion that institutions are the fundamental cause of long-run economic growth, sugges

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6
