# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 10 of 50 documents (5 streams, 1 unassigned).

**Relation distribution:** adjacent: 7, same_as_topic_cause: 2

---

## Institutional changes due to colonialism  (C1 — same_as_topic_cause)

**Stream posture:** Institutional changes introduced by colonialism are a key factor in explaining long-run economic growth, as evidenced by the reversal in relative incomes among former European colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Reversal of fortune and economic divergence  (C2 — adjacent)

**Stream posture:** The 'reversal of fortune' thesis and economic divergence are discussed through various historical lenses, but these discussions do not directly address how institutions fundamentally cause long-run economic growth.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 64.1

## Catch-up process in economic growth  (C5 — adjacent)

**Stream posture:** Abramovitz (1986) discusses the complexities of the catch-up process in economic growth, highlighting the influence of exogenous factors and technological advancements, but does not directly address institutions as a fundamental cause of long-run economic growth.

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 60.0

## Real wages and economic stagnation in China  (C4 — adjacent)

**Stream posture:** This cluster focuses on the stagnation of real wages in China from the eighteenth to early twentieth centuries, contrasting it with other regions and periods without directly addressing institutions as a cause of long-run economic growth.

**Sources:**
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 54.6

## Economic and institutional changes in Africa  (C3 — adjacent)

**Stream posture:** The cluster examines various institutional changes in Africa, including the role of women in economic development and shifts in land use rights, but does not directly address how these changes lead to long-run economic growth.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 70.1
- Bohannan, P. (1959) 'The impact of money on an African subsistence economy', The Journal of Economic History, 19(4), pp. 491-503. - avg score 58.0

## Unassigned (1)

- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651.
