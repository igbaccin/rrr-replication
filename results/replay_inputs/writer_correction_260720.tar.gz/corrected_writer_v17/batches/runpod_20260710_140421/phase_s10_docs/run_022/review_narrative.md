# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 10 of 50 documents (6 streams, 0 unassigned).

**Relation distribution:** adjacent: 9, rival_to_topic_cause: 1

---

## Institutional revolution in factor markets and reversal of fortune thesis  (C2 — adjacent)

**Stream posture:** Austin (2007) examines how shifts in land abundance and scarcity influenced market dynamics in Ghana during 1874-1939.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 70.1

## Institutional changes due to colonialism and mortality rates  (C1 — adjacent)

**Stream posture:** The cluster examines how institutional changes introduced by colonialism led to a reversal in relative incomes among former European colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Divergence in real incomes and wage stagnation  (C4 — adjacent)

**Stream posture:** The cluster examines the historical patterns of real income divergence and wage stagnation without directly linking these outcomes to institutional factors.

**Sources:**
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 64.1
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 54.6

## Economic contributions of African women and introduction of money in subsistence economy  (C5 — adjacent)

**Stream posture:** The literature on African women's economic contributions and the introduction of money in subsistence economies highlights significant economic changes but does not directly address how institutions fundamentally drive long-run economic growth.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Bohannan, P. (1959) 'The impact of money on an African subsistence economy', The Journal of Economic History, 19(4), pp. 491-503. - avg score 58.0

## Collaborative research on economic performance measurement  (C6 — adjacent)

**Stream posture:** This cluster emphasizes the necessity of collaborative research for accurate measurement of economic performance, highlighting the ongoing debate and need for improved data on historical economic development.

**Sources:**
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651. - avg score 73.2

## Catch-up process in economic growth  (C3 — rival_to_topic_cause)

**Stream posture:** Abramovitz argues that the catch-up process in economic growth is complex and influenced by technological advance and social change, challenging simple convergence hypotheses.

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 60.0
