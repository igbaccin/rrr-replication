# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (8 streams, 6 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 2, same_as_topic_cause: 2, upstream_of_topic_cause: 4

---

## Institutional evolution and economic growth in Europe  (C1 — upstream_of_topic_cause)

**Stream posture:** The evolution of financial institutions, such as the Bank of England, played a pivotal role in reducing transaction costs and fostering secure property rights, which were crucial for long-run economic growth.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 85.3
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 83.8

## Role of distributional conflicts and marginalized groups in economic institutions  (C7 — upstream_of_topic_cause)

**Stream posture:** Distributional conflicts, rather than efficiency, are argued to be the driving force behind key economic institutions in pre-industrial Europe, challenging the conventional view that these institutions were shaped by efficiency considerations.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 84.7
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3

## Colonial institutions and economic development  (C2 — same_as_topic_cause)

**Stream posture:** Colonial institutions shaped by European policies significantly influenced long-run economic growth in former colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Institutional and cultural impacts of slavery on economic development  (C4 — adjacent)

**Stream posture:** The institutional and cultural impacts of slavery on economic development highlight how historical inequalities shaped by institutions have persisted over time.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 80.5
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 77.5
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 74.2

## Early modern economic divergence and structural changes  (C8 — adjacent)

**Stream posture:** Pamuk (2007) argues that the Black Death initiated long-term structural changes leading to a wage gap between northwestern Europe and the rest of Europe by 1450, highlighting early modern economic divergence through demographic shifts rather than institutional factors.

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 74.2
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 72.4

## Revisiting the 'reversal of fortune' thesis in economic history  (C6 — adjacent)

**Stream posture:** This cluster challenges the 'reversal of fortune' thesis by examining different historical periods and paths, arguing that the thesis oversimplifies causation. It does not directly address institutions as the fundamental cause of long-run economic growth but rather focuses on the

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 75.4

## Technological progress and economic growth  (C5 — rival_to_topic_cause)

**Stream posture:** Mokyr argues that technological progress, driven by the growth of useful knowledge, is the primary driver of economic growth. This perspective contrasts with the institutional view, suggesting that advancements in technology and knowledge are more fundamental than institutional f

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 75.5
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 74.8

## African economic development and colonial impact  (C3 — adjacent)

**Stream posture:** The cluster discusses how institutional change in African colonies was influenced by both African initiatives and exogenous factors, impacting the quality of public goods provided by African governments. This focus on colonial impact and institutional change does not directly add

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 84.0
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.2
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 75.5

## Unassigned (6)

- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197.
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438.
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651.
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68.
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
