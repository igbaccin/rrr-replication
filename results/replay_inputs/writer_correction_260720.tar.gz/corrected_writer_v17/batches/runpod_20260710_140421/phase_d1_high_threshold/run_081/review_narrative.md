# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (8 streams, 5 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 6, same_as_topic_cause: 3

---

## Institutional impact on economic growth and development  (C1 — same_as_topic_cause)

**Stream posture:** North (1989) argues that institutions are crucial for economic growth, contrasting with neoclassical theories that emphasize population and savings.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 85.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Historical institutional changes and their effects on economic outcomes  (C2 — adjacent)

**Stream posture:** The evolution of institutions governing public choice in seventeenth-century England was crucial for fostering secure property rights and economic growth, highlighting the political factors underpinning economic development.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 83.8

## Economic divergence and historical standards of living  (C8 — adjacent)

**Stream posture:** This cluster examines the great divergence between Europe and Asia before 1800 and the relationship between economic development and standards of living in Europe from 1500 to 1800, but it does not directly address how institutions influence long-run economic growth.

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 74.2
- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197. - avg score 72.9

## Economic policies and their impact on African development  (C6 — adjacent)

**Stream posture:** This cluster examines specific economic policies and their impacts on African development, focusing on budget policies, the legacy of the slave trade, and historical economic performance. These studies do not directly address how institutions fundamentally cause long-run economic

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 80.5
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 75.7
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 75.5

## Colonial and post-colonial institutional impacts on African development  (C3 — adjacent)

**Stream posture:** The impact of British rule on formal education in sub-Saharan Africa highlights a specific institutional legacy that influenced development trajectories.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 84.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.2

## Historical factors and their long-term effects on African economic development  (C7 — rival_to_topic_cause)

**Stream posture:** The historical factors and their long-term effects on African economic development suggest that Africa's slave trades had an adverse effect on economic development, challenging those who attribute Africa's underdevelopment solely to other factors such as colonialism or more recen

**Sources:**
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 75.4
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 74.2

## Institutional explanations for economic inequality and distributional conflicts  (C4 — rival_to_topic_cause)

**Stream posture:** Distributional conflicts, rather than institutional efficiency, are argued to better explain the core economic institutions of pre-industrial Europe.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 84.7
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 77.5

## Technological and knowledge-driven economic growth  (C5 — rival_to_topic_cause)

**Stream posture:** The growth of useful knowledge is highlighted as a primary driver of economic growth, suggesting that technological advancements and the accumulation of knowledge are crucial for sustained economic development.

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 75.5
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 74.8

## Unassigned (5)

- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314.
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651.
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68.
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
