# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (11 streams, 0 unassigned).

**Relation distribution:** adjacent: 15, rival_to_topic_cause: 4, same_as_topic_cause: 3, upstream_of_topic_cause: 2

---

## Economic development and structural changes in Europe  (C9 — same_as_topic_cause)

**Stream posture:** The role of institutions in shaping long-term economic performance is highlighted by van Zanden (2009), who emphasizes that formal institutions like guilds were crucial for ensuring fair execution of apprentice contracts, thereby influencing economic outcomes.

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 77.2
- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197. - avg score 72.9
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 72.4

## Institutions and property rights in England  (C2 — adjacent)

**Stream posture:** The evolution of institutions governing public choice in seventeenth-century England was pivotal for fostering secure property rights and economic growth.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 85.3
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 83.8

## Distributional conflicts and economic institutions  (C7 — upstream_of_topic_cause)

**Stream posture:** Ogilvie (2007) and Peters (2004) argue that distributional conflicts are a better explanation for economic institutions than efficiency considerations.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 84.7
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 71.3

## Impact of slave trade on African development  (C4 — adjacent)

**Stream posture:** The slave trade in Africa led to a culture of mistrust that persists today, impacting trust levels and economic development.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 80.5
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 74.2

## Economic performance and colonial impacts in Africa  (C6 — adjacent)

**Stream posture:** This cluster examines the economic performance and colonial impacts in Africa, focusing on specific historical and policy aspects without directly addressing how institutions fundamentally cause long-run economic growth.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.2
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 75.7
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 75.5

## Institutional changes due to colonialism  (C1 — adjacent)

**Stream posture:** The literature on institutional changes due to colonialism explores how different colonization strategies led to varying economic outcomes in former European colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Institutional reforms and poverty in Africa  (C3 — adjacent)

**Stream posture:** The literature on institutional reforms in Africa highlights specific interventions aimed at reducing poverty but does not directly address long-run economic growth as a fundamental outcome.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 84.0
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 75.4

## Economic inequality and institutional policies  (C5 — adjacent)

**Stream posture:** This cluster examines how economic inequality is shaped by various government policies and the role of women in economic development, without directly addressing the fundamental role of institutions in long-run economic growth.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 77.5

## Technological advancements and economic growth  (C8 — rival_to_topic_cause)

**Stream posture:** The cluster argues that technological advancements, specifically the growth of useful knowledge, are the primary driver of long-run economic growth, contrasting with the view that institutions are the fundamental cause.

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 75.5
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 74.8
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 74.2

## Collaborative research on economic performance  (C10 — adjacent)

**Stream posture:** This cluster emphasizes the necessity of collaborative research for accurate measurements of economic performance, highlighting the ongoing debate and updates to historical economic data. It does not engage with the role of institutions in long-run economic growth.

**Sources:**
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651. - avg score 73.2

## Ideas and ideologies driving economic change  (C11 — rival_to_topic_cause)

**Stream posture:** McCloskey argues that ideas and ideologies were the primary drivers of economic change in Northwestern Europe from 1600 to 1848, challenging institutional theories.

**Sources:**
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68. - avg score 70.6
