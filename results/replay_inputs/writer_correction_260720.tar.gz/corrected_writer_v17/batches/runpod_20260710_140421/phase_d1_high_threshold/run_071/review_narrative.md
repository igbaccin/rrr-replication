# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (10 streams, 2 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 7, same_as_topic_cause: 5

---

## Institutional determinants of economic growth  (C1 — same_as_topic_cause)

**Stream posture:** Institutional determinants of economic growth are crucial, as evidenced by historical examples such as the English financial revolution and the development of secure property rights in seventeenth-century England.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 85.3
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 83.8

## Colonial institutions and economic outcomes  (C2 — same_as_topic_cause)

**Stream posture:** Colonial institutions shaped by European mortality rates significantly influenced long-run economic growth in former colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5

## Institutional impacts on economic inequality  (C4 — rival_to_topic_cause)

**Stream posture:** Ogilvie argues that distributional conflicts, rather than efficiency, better explain key economic institutions in pre-industrial Europe.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 84.7
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 77.5

## Technological and knowledge drivers of economic growth  (C5 — rival_to_topic_cause)

**Stream posture:** The growth of useful knowledge is seen as a primary driver of economic growth, suggesting that technological and knowledge drivers are fundamental to long-run economic performance.

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 75.5
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 74.8

## Historical impacts of the slave trade on economic development  (C9 — rival_to_topic_cause)

**Stream posture:** The historical impacts of the slave trade on economic development suggest that the legacy of mistrust and institutional breakdowns caused by the slave trade may have hindered long-run economic growth in Africa.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 80.5
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 74.2
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 72.4

## African economic history and institutional reforms  (C3 — adjacent)

**Stream posture:** This cluster examines the role of women in African economic development and the impact of colonial rule on institutional changes, but it does not directly address how institutions fundamentally cause long-run economic growth.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 84.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3

## Economic performance and colonial impacts in Africa and Asia  (C6 — adjacent)

**Stream posture:** This cluster examines the economic performance and colonial impacts in Africa and Asia, focusing on specific historical contexts and outcomes rather than directly addressing the role of institutions in long-run economic growth.

**Sources:**
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.2
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 75.5
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 74.2

## Post-colonial economic policies and poverty  (C8 — adjacent)

**Stream posture:** This cluster examines the nuances of post-independence budget policies and the historical determinants of African poverty, offering insights into specific economic phenomena without directly addressing the role of institutions in long-run economic growth.

**Sources:**
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 75.7
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 75.4

## Measurement of economic performance  (C7 — adjacent)

**Stream posture:** This cluster focuses on the measurement of economic performance and the determinants of the skill premium, rather than directly addressing how institutions influence long-run economic growth.

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 77.2
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651. - avg score 73.2

## Land systems and class formation in Africa  (C10 — adjacent)

**Stream posture:** Peters_2004 argues that reports of negotiable land systems in Africa conceal processes of exclusion and class formation, highlighting the complexities of political-economic and social processes in state-making.

**Sources:**
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 71.3

## Unassigned (2)

- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197.
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68.
