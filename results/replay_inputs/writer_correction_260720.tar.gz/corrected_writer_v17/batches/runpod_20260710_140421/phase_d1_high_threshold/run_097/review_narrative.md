# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (11 streams, 3 unassigned).

**Relation distribution:** adjacent: 10, rival_to_topic_cause: 5, same_as_topic_cause: 4, upstream_of_topic_cause: 2

---

## Colonial institutions and economic outcomes  (C1 — same_as_topic_cause)

**Stream posture:** Colonial institutions shaped by European policies significantly influenced long-run economic growth in former colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Colonial impacts on African economic performance  (C7 — same_as_topic_cause)

**Stream posture:** British rule in sub-Saharan Africa fostered formal education more effectively than other colonial powers, contributing to higher per capita income levels by the early twentieth century.

**Sources:**
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.2
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 75.5

## Institutions and property rights in England  (C2 — adjacent)

**Stream posture:** The evolution of institutions governing public choice in seventeenth-century England was pivotal for fostering secure property rights and economic growth.

**Sources:**
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 85.3
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 83.8

## Institutional impacts on inequality and economic growth  (C3 — upstream_of_topic_cause)

**Stream posture:** Distributional conflicts, rather than institutions themselves, are argued to be the fundamental drivers of long-run economic growth, challenging the notion that institutions are the primary cause.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 84.7
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 77.5

## Revisiting the 'reversal of fortune' thesis  (C4 — adjacent)

**Stream posture:** This cluster challenges the 'reversal of fortune' thesis by arguing that it oversimplifies causation, particularly in the context of African economic history. It does not directly address institutions as the fundamental cause of long-run economic growth but rather critiques the h

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 75.4

## African economic development and institutions  (C5 — adjacent)

**Stream posture:** This cluster examines African economic development through the lens of women's contributions and colonial influences, rather than focusing on institutional frameworks as the fundamental cause of long-run economic growth.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 84.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3

## Impact of slave trade on African economic development  (C6 — rival_to_topic_cause)

**Stream posture:** The slave trades in Africa are argued to have had a direct adverse effect on long-run economic development, challenging views that attribute Africa's underdevelopment solely to colonialism or more recent events.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 80.5
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 74.2

## Technology, knowledge, and economic growth  (C9 — rival_to_topic_cause)

**Stream posture:** Mokyr (2005) argues that the growth of useful knowledge is the primary driver of economic growth, contrasting with the view that institutions are the fundamental cause.

**Sources:**
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 75.5
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 74.8

## Budget policies and land systems in Africa  (C8 — adjacent)

**Stream posture:** The literature on budget policies and land systems in Africa focuses on specific institutional dynamics without directly addressing long-run economic growth.

**Sources:**
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 75.7
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314. - avg score 71.3

## Measuring and predicting economic performance  (C10 — adjacent)

**Stream posture:** This cluster focuses on methodologies for measuring and predicting long-term economic performance, rather than directly addressing the role of institutions in driving economic growth.

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 77.2
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651. - avg score 73.2

## Ideas and ideologies driving economic change  (C11 — rival_to_topic_cause)

**Stream posture:** McCloskey argues that ideas and ideologies, not institutions, were the primary drivers of economic change in Northwestern Europe from 1600 to 1848, challenging interest-only theories.

**Sources:**
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68. - avg score 70.6

## Unassigned (3)

- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197.
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31.
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317.
