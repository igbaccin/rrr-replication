# Literature review

**Topic:** Gender and development shaped long-run economic outcomes

**Topic shape:** causal

**Coverage:** 24 of 50 documents (8 streams, 2 unassigned).

**Relation distribution:** adjacent: 20, rival_to_topic_cause: 2

---

## Gender roles in economic development  (C1 — rival_to_topic_cause)

**Stream posture:** The cluster argues that a quiet revolution in women's employment transformed long-run economic outcomes, challenging views that see this change as merely evolutionary or stalled.

**Sources:**
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21. - avg score 100.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 94.2

## Institutional impact on economic growth  (C2 — adjacent)

**Stream posture:** The institutional impact on economic growth in New World societies highlights how unequal power distributions shaped by institutions led to policies that restricted competition and maintained inequality.

**Sources:**
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153. - avg score 100.0
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 91.4
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 90.6

## Labor allocation and economic growth  (C3 — adjacent)

**Stream posture:** This cluster examines how labor allocation between agriculture and industry influenced economic growth, particularly during Europe's post-WWII Golden Age. It does not directly address the role of gender and development in shaping long-run economic outcomes.

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 88.3
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 84.4

## Economic growth and institutional frameworks  (C4 — adjacent)

**Stream posture:** This cluster examines the role of institutions and economic growth, highlighting how secure property rights and human capital formation influenced historical economic development. However, it does not directly address the impact of gender and development on long-run economic outc

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 91.4
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 81.1
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 78.7

## Technological and institutional drivers of economic growth  (C5 — adjacent)

**Stream posture:** This cluster examines how technological advancements and institutional frameworks drive economic growth, offering insights into the broader mechanisms that shape long-run economic outcomes without directly addressing the role of gender and development.

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 84.4
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 84.4
- De Vries, J. (1994) 'The industrial revolution and the industrious revolution', The Journal of Economic History, 54(2), pp. 249-270. - avg score 84.0

## Ideological and biological factors in economic development  (C6 — adjacent)

**Stream posture:** The literature on ideological and biological factors in economic development does not directly address the role of gender and development in shaping long-run economic outcomes. Instead, it focuses on other determinants such as ideas, ideologies, and biological well-being during p

**Sources:**
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 83.3
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68. - avg score 79.2
- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197. - avg score 78.7

## Economic institutions and structural changes  (C7 — adjacent)

**Stream posture:** This cluster examines various economic institutions and structural changes, such as the role of serfdom, guilds, and budget policies, without directly addressing how gender and development shaped long-run economic outcomes.

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 81.0
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 78.8
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 77.8

## Historical events and economic development  (C8 — adjacent)

**Stream posture:** The Black Death initiated long-term structural changes that led to a wage gap between the northwest and the rest of Europe by 1450.

**Sources:**
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 78.5
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 77.8
- Koepke, N. and Baten, J. (2005) 'The biological standard of living in Europe during the last two millennia', European Review of Economic History, 9(1), pp. 61-95. - avg score 77.7

## Unassigned (2)

- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027.
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439.
