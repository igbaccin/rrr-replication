# Literature review

**Topic:** Gender and development shaped long-run economic outcomes

**Topic shape:** causal

**Coverage:** 24 of 50 documents (8 streams, 3 unassigned).

**Relation distribution:** adjacent: 18, rival_to_topic_cause: 3

---

## Gender roles in economic development  (C1 — adjacent)

**Stream posture:** The role of African women in economic growth and development during pre-colonial and colonial periods highlights their significant contributions, challenging views that marginalize their impact.

**Sources:**
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21. - avg score 100.0
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 94.2

## Institutional changes and inequality  (C2 — rival_to_topic_cause)

**Stream posture:** Institutional changes introduced by colonialism are argued to have significantly influenced long-run economic outcomes, particularly the reversal in relative incomes among former European colonies.

**Sources:**
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232. - avg score 91.4
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 90.6
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 86.4

## Economic transformations and labor dynamics  (C6 — adjacent)

**Stream posture:** This cluster examines the impact of economic transformations and labor dynamics on long-run economic outcomes, but it does not directly address how gender and development shape these outcomes.

**Sources:**
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22. - avg score 88.3
- De Vries, J. (1994) 'The industrial revolution and the industrious revolution', The Journal of Economic History, 54(2), pp. 249-270. - avg score 84.0
- Komlos, J. (1998) 'Shrinking in a growing economy? The mystery of physical stature during the Industrial Revolution', The Journal of Economic History, 58(3), pp. 779-802. - avg score 83.3

## Economic divergence and historical events  (C7 — adjacent)

**Stream posture:** This cluster examines how historical events like the Black Death and Africa's slave trades influenced long-term economic outcomes, but does not address the role of gender and development in shaping these outcomes.

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 78.8
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317. - avg score 78.5
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 77.8

## Distributional conflicts and economic institutions  (C8 — adjacent)

**Stream posture:** This cluster examines how distributional conflicts shaped core economic institutions, such as serfdom and guilds in pre-industrial Europe, and the budget policies of post-independence East Africa. These studies do not directly address gender and development but offer insights int

**Sources:**
- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684. - avg score 81.0
- Simson, R. (2019) 'Africa's clientelist budget policies revisited: public expenditure and employment in Kenya, Tanzania and Uganda, 1960--2010', The Economic History Review, 72(4), pp. 1409-1438. - avg score 77.8

## Economic performance in pre-industrial societies  (C4 — adjacent)

**Stream posture:** Research on pre-industrial economies has often focused on understanding economic performance without explicitly linking it to gender dynamics or long-run economic outcomes.

**Sources:**
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 84.4
- Van Zanden, J. (1999) 'Wages and the standard of living in Europe, 1500--1800', European Review of Economic History, 3(2), pp. 175-197. - avg score 78.7

## Drivers of economic growth  (C5 — adjacent)

**Stream posture:** The papers in this cluster explore various drivers of economic growth, including useful knowledge, technology, and ideas/ideologies. These factors are distinct from gender and development as drivers of long-run economic outcomes.

**Sources:**
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351. - avg score 84.4
- Kuznets, S. (1973) 'Modern economic growth: findings and reflections', The American Economic Review, 63(3), pp. 247-258. - avg score 84.4
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68. - avg score 79.2

## Institutions and economic growth  (C3 — adjacent)

**Stream posture:** This cluster focuses on how institutional and ideological adjustments foster economic growth, contrasting with the broader theme of gender and development shaping long-run economic outcomes.

**Sources:**
- Lindert, P. and Williamson, J. (1985) 'Growth, equality, and history', Explorations in Economic History, 22(4), pp. 341-377. - avg score 91.4
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 81.1
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 78.7

## Unassigned (3)

- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
- Stern, D. (2004) 'The rise and fall of the environmental Kuznets curve', World Development, 32(8), pp. 1419-1439.
- Koepke, N. and Baten, J. (2005) 'The biological standard of living in Europe during the last two millennia', European Review of Economic History, 9(1), pp. 61-95.
