# Literature review

**Topic:** Colonial institutions explain African economic growth trajectories

**Topic shape:** causal

**Coverage:** 24 of 50 documents (6 streams, 12 unassigned).

**Relation distribution:** adjacent: 10, same_as_topic_cause: 2

---

## Colonial institutions and economic growth  (C1 — same_as_topic_cause)

**Stream posture:** The institutional changes introduced by colonialism are a key factor in shaping African economic growth trajectories.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 100.0
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 86.3

## Institutional change in African economies  (C2 — adjacent)

**Stream posture:** Austin (2007) argues that the shift from land abundance to localised scarcity in Ghana during 1874-1939 led to an institutional revolution in factor markets, marked by the emergence of widespread markets in land use rights and hired labour.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 83.8
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 64.3

## Colonial impacts on African economic performance  (C5 — adjacent)

**Stream posture:** British rule was more conducive to the development of formal education in sub-Saharan Africa than other colonial powers.

**Sources:**
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 68.6
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 64.0

## Economic history and institutional reforms in Africa  (C4 — adjacent)

**Stream posture:** This cluster examines the broader context of African economic history and institutional reforms, offering insights into how different factors have influenced Africa's development without directly addressing the impact of colonial institutions on economic growth trajectories.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 81.6
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 63.6

## Institutions and economic growth in Europe  (C6 — adjacent)

**Stream posture:** The literature on institutions and economic growth in Europe highlights how secure property rights and financial innovations fostered long-term economic success, contrasting with neoclassical theories that emphasize population and savings. This cluster does not directly address c

**Sources:**
- North, D. and Weingast, B. (1989) 'Constitutions and commitment: the evolution of institutions governing public choice in seventeenth-century England', The Journal of Economic History, 49(4), pp. 803-832. - avg score 71.1
- North, D. (1989) 'Institutions and economic growth: An historical introduction', World Development, 17(9), pp. 1319-1332. - avg score 70.9

## Impact of slave trade on African development  (C3 — adjacent)

**Stream posture:** The slave trade in Africa led to a culture of mistrust that persists today and significantly impacts trust levels within African societies.

**Sources:**
- Nunn, N. and Wantchekon, L. (2011) 'The slave trade and the origins of mistrust in Africa', American Economic Review, 101(7), pp. 3221-3252. - avg score 71.8
- Nunn, N. (2008) 'The long-term effects of Africa's slave trades', The Quarterly Journal of Economics, 123(1), pp. 139-176. - avg score 65.8

## Unassigned (12)

- Ogilvie, S. (2007) '‘Whatever is, is right’? Economic institutions in pre-industrial Europe', The Economic History Review, 60(4), pp. 649-684.
- Sokoloff, K. and Engerman, S. (2000) 'History lessons: institutions, factor endowments, and paths of development in the new world', Journal of Economic Perspectives, 14(3), pp. 217-232.
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15.
- Pamuk, c. (2007) 'The Black Death and the origins of the ‘Great Divergence’ across Europe, 1300--1600', European Review of Economic History, 11(3), pp. 289-317.
- Temin, P. (2002) 'The golden age of European growth reconsidered', European Review of Economic History, 6(1), pp. 3-22.
- McCloskey, D. (2015) 'It was ideas and ideologies, not interests or institutions, which changed in Northwestern Europe, 1600--1848', Journal of Evolutionary Economics, 25(1), pp. 57-68.
- Bryceson, D. (2002) 'The scramble in Africa: reorienting rural livelihoods', World Development, 30(5), pp. 725-739.
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444.
- Peters, P. (2004) 'Inequality and social conflict over land in Africa', Journal of Agrarian Change, 4(3), pp. 269-314.
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73.
- Mokyr, J. (2005) 'The intellectual origins of modern economic growth', The Journal of Economic History, 65(2), pp. 285-351.
- Van Zanden, J. (2009) 'The skill premium and the ‘Great Divergence’', European Review of Economic History, 13(1), pp. 121-153.
