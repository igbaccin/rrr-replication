# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (6 streams, 12 unassigned).

**Relation distribution:** adjacent: 10, same_as_topic_cause: 2

---

## Colonial institutions and economic outcomes  (C1 — same_as_topic_cause)

**Stream posture:** Colonial institutions shaped by European policies significantly influenced long-run economic growth in former colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Reevaluating the 'reversal of fortune' thesis  (C2 — adjacent)

**Stream posture:** This cluster re-evaluates specific historical narratives about economic development, such as the 'reversal of fortune' thesis and the economic performance of Anglophone African economies in the early twentieth century. These studies challenge conventional views by providing new e

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 75.5

## Impact of colonial rule on African development  (C3 — adjacent)

**Stream posture:** The literature on the impact of colonial rule on African development highlights specific historical and educational developments without directly addressing how institutions fundamentally shape long-run economic growth.

**Sources:**
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.2
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 75.4

## Early modern economic divergence between Europe and Asia  (C4 — adjacent)

**Stream posture:** The early modern economic divergence between Europe and Asia is explored through various lenses, including productivity in traded goods sectors, climate effects, and revenue changes under different rulers. However, these discussions do not coalesce around a specific institutional

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 74.2
- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447. - avg score 64.1
- Broadberry, S., Custodis, J. and Gupta, B. (2015) 'India and the great divergence: An Anglo-Indian comparison of GDP per capita, 1600--1871', Explorations in Economic History, 55, pp. 58-75. - avg score 58.7

## Property rights and agricultural development  (C5 — adjacent)

**Stream posture:** The introduction of barbed wire fencing significantly enhanced agricultural development on the American Plains by enabling farmers to better protect their property rights and reduce externalities from livestock damage.

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 69.0

## Revisiting Eurocentric and gender perspectives in economic history  (C6 — adjacent)

**Stream posture:** This cluster challenges traditional views of economic progress by examining the roles of non-Western societies and women's contributions to economic development. It does not directly address how institutions influence long-run economic growth but offers alternative perspectives o

**Sources:**
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21. - avg score 68.5
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 67.1

## Unassigned (12)

- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177.
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73.
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120.
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15.
- Bohannan, P. (1959) 'The impact of money on an African subsistence economy', The Journal of Economic History, 19(4), pp. 491-503.
- Bryceson, D. (2002) 'The scramble in Africa: reorienting rural livelihoods', World Development, 30(5), pp. 725-739.
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38.
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406.
- Domar, E. (1970) 'The causes of slavery or serfdom: a hypothesis', The Journal of Economic History, 30(1), pp. 18-32.
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658.
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651.
- Braudel, F. and Wallerstein, I. (2009) 'History and the social sciences: the longue dur\'ee', Review (Fernand Braudel Center), pp. 171-203.
