# Literature review

**Topic:** Institutions are the fundamental cause of long-run economic growth

**Topic shape:** causal

**Coverage:** 24 of 50 documents (11 streams, 2 unassigned).

**Relation distribution:** adjacent: 20, same_as_topic_cause: 2

---

## Institutional impact of colonialism on economic growth  (C1 — same_as_topic_cause)

**Stream posture:** Colonialism introduced institutional changes that significantly impacted long-run economic growth, as evidenced by the reversal in relative incomes among former European colonies.

**Sources:**
- Acemoglu, D., Johnson, S. and Robinson, J. (2001) 'The colonial origins of comparative development: An empirical investigation', American Economic Review, 91(5), pp. 1369-1401. - avg score 87.9
- Acemoglu, D., Johnson, S. and Robinson, J. (2002) 'Reversal of fortune: Geography and institutions in the making of the modern world income distribution', The Quarterly Journal of Economics, 117(4), pp. 1231-1294. - avg score 84.6

## Impact of property rights on economic development  (C8 — adjacent)

**Stream posture:** The introduction of barbed wire fencing significantly enhanced agricultural development on the American Plains by enabling farmers to better protect their property rights and reduce externalities from livestock damage.

**Sources:**
- Hornbeck, R. (2010) 'Barbed wire: Property rights and agricultural development', The Quarterly Journal of Economics, 125(2), pp. 767-810. - avg score 69.0
- Domar, E. (1970) 'The causes of slavery or serfdom: a hypothesis', The Journal of Economic History, 30(1), pp. 18-32. - avg score 60.2

## Reversal of fortune thesis and institutional changes in Africa  (C4 — adjacent)

**Stream posture:** Austin_2007 examines how shifts in land abundance led to institutional changes in Ghana, focusing on the emergence of markets for land use rights and hired labor.

**Sources:**
- Austin, G. (2008) 'The ‘reversal of fortune’ thesis and the compression of history: Perspectives from African and comparative economic history', Journal of International Development: The Journal of the Development Studies Association, 20(8), pp. 996-1027. - avg score 85.5
- Austin, G. (2007) 'Labour and land in Ghana, 1874--1939: a shifting ratio and an institutional revolution', Australian Economic History Review, 47(1), pp. 95-120. - avg score 70.1

## Educational and economic impacts of British rule in Africa  (C2 — adjacent)

**Stream posture:** The impact of British rule on education in sub-Saharan Africa is examined, highlighting how colonial policies influenced educational development rather than directly addressing institutional frameworks as a cause of long-run economic growth.

**Sources:**
- Frankema, E. (2012) 'The origins of formal education in sub-Saharan Africa: was British rule more benign?', European Review of Economic History, 16(4), pp. 335-355. - avg score 78.2
- Frankema, E. and Van Waijenburg, M. (2012) 'Structural impediments to African growth? New evidence from real wages in British Africa, 1880--1965', The Journal of Economic History, 72(4), pp. 895-926. - avg score 75.4

## African economic history and institutional reforms  (C3 — adjacent)

**Stream posture:** The literature on African economic history and institutional reforms provides valuable insights into the historical context and development of institutions in Africa, but it does not directly address how these institutions fundamentally cause long-run economic growth.

**Sources:**
- Hopkins, A. (2009) 'The new economic history of Africa', The Journal of African History, 50(2), pp. 155-177. - avg score 84.0
- Hopkins, A. (2019) 'Fifty years of African economic history', Economic History of Developing Regions, 34(1), pp. 1-15. - avg score 65.2

## Economic performance and institutional factors in Africa and India  (C5 — adjacent)

**Stream posture:** The cluster examines the economic performance of Anglophone African economies and India, highlighting their per capita income levels and historical economic trends without directly linking these outcomes to institutional factors.

**Sources:**
- Broadberry, S. and Gardner, L. (2022) 'Economic growth in Sub-Saharan Africa, 1885--2008: Evidence from eight countries', Explorations in Economic History, 83, pp. 101424. - avg score 75.5
- Broadberry, S., Custodis, J. and Gupta, B. (2015) 'India and the great divergence: An Anglo-Indian comparison of GDP per capita, 1600--1871', Explorations in Economic History, 55, pp. 58-75. - avg score 58.7

## Great divergence between Europe and Asia  (C7 — adjacent)

**Stream posture:** The great divergence between Europe and Asia is often attributed to various factors, including institutional differences, but these papers focus on the historical context and specific conditions that led to this divergence without directly linking it to institutions causing long-

**Sources:**
- Broadberry, S. and Gupta, B. (2006) 'The early modern great divergence: wages, prices and economic development in Europe and Asia, 1500--1800', The Economic History Review, 59(1), pp. 2-31. - avg score 74.2
- Bryant, J. (2006) 'The West and the rest revisited: Debating capitalist origins, European colonialism, and the advent of modernity', Canadian Journal of Sociology/Cahiers canadiens de sociologie, pp. 403-444. - avg score 67.1

## Women's contributions to economic growth and development  (C6 — adjacent)

**Stream posture:** This cluster highlights the significant roles played by women in economic growth and development, both historically and contemporarily. It does not, however, engage with the institutional framework that underpins long-term economic growth.

**Sources:**
- Akyeampong, E. and Fofack, H. (2014) 'The contribution of African women to economic growth and development in the pre-colonial and colonial periods: historical perspectives and policy implications', Economic History of Developing Regions, 29(1), pp. 42-73. - avg score 83.3
- Goldin, C. (2006) 'The quiet revolution that transformed women's employment, education, and family', American Economic Review, 96(2), pp. 1-21. - avg score 68.5

## Technological advance, social change and economic growth  (C10 — adjacent)

**Stream posture:** The dynamics of technological advance and social change are pivotal in shaping economic growth, influencing productivity scales and regional migration patterns.

**Sources:**
- Abramovitz, M. (1986) 'Catching up, forging ahead, and falling behind', The Journal of Economic History, 46(2), pp. 385-406. - avg score 60.0
- Allen, R., Bassino, J., Ma, D., Moll-Murata, C. and Van Zanden, J. (2011) 'Wages, prices, and living standards in China, 1738--1925: in comparison with Europe, Japan, and Indi', The Economic History Review, 64(64), pp. 8-38. - avg score 54.6

## Economic performance and standard of living improvements  (C9 — adjacent)

**Stream posture:** This cluster emphasizes the importance of accurate measurements in understanding economic performance globally, highlighting the need for collaborative research to refine estimates and address uncertainties.

**Sources:**
- Bolt, J. and Van Zanden, J. (2014) 'The Maddison Project: collaborative research on historical national accounts', The Economic History Review, 67(3), pp. 627-651. - avg score 73.2
- Feinstein, C. (1998) 'Pessimism perpetuated: real wages and the standard of living in Britain during and after the industrial revolution', The Journal of Economic History, 58(3), pp. 625-658. - avg score 59.8

## Social changes due to economic restructuring in Africa  (C11 — adjacent)

**Stream posture:** The introduction of money into African subsistence economies led to profound changes and a shift away from multicentric economies, highlighting the deep social transformations that accompany economic restructuring in Africa.

**Sources:**
- Bohannan, P. (1959) 'The impact of money on an African subsistence economy', The Journal of Economic History, 19(4), pp. 491-503. - avg score 58.0
- Bryceson, D. (2002) 'The scramble in Africa: reorienting rural livelihoods', World Development, 30(5), pp. 725-739. - avg score 56.9

## Unassigned (2)

- Allen, R. (2001) 'The great divergence in European wages and prices from the Middle Ages to the First World War', Explorations in Economic History, 38(4), pp. 411-447.
- Braudel, F. and Wallerstein, I. (2009) 'History and the social sciences: the longue dur\'ee', Review (Fernand Braudel Center), pp. 171-203.
